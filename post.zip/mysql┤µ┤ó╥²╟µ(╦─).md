---
title: "Mysql存储引擎(四)"
date: 2019-09-29T18:04:59+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
Mysql存储引擎
<!--more-->
常用存储引擎

innodb(mysql oracle 5.6以后的默认版本,mariadb默认innodb,另外提供tokudb主要是用于大量插件): 一般业务使用

优点: 

**事务安全（遵从ACID）

**出现故障后快速自动恢复（Crash Safe Recovery）

**MVCC（Multi-Versioning Concurrency Control，多版本并发控制）

**InnoDB行级别锁定

**支持外键引用完整性约束

Oracle 样式一致非锁定读取表数据进行整理来优化基于主键的查询大型数据卷上的最大性能, 将对表的查询与不同存储引擎混合, 用于在内存中缓存数据和索引的缓冲区池

tokudb: 针对业务类型是insert 很多用于zabbix,爬虫数据存储

存储引擎查看
show engines\G; 查看所有存储引擎

创建表设置存储引擎create table t (id int) engine=innodb

存储引擎设置
0、查询mysql支持的存储引擎：

show engines;

1、在启动配置文件中设置服务器存储引擎：

[mysqld]

default-storage-engine=innodb

2、使用SET 命令为当前客户机会话设置：

SET @@storage_engine=innodb;

3、在CREATE TABLE 语句指定：

CREATE TABLE t (id INT) ENGINE = innodb;

MySQL物理存储结构

共享表空间:

可扩展(随着存储需求,进行扩容,最后的存储可设置为无限扩容)

把所有的数据都存储到一个表空间

所有数据库对象(基表,用户数据,undo数据,临时表数据)都存在一个表空间,管理耦合度过高

文件存放在data目录下,被命名为ibdata1-ibdataN

独立表空间:

每个表单独存储,文件锁着数据量的增加自动扩容,耦合度更低

在表的数据库目录下

设置表空间: innodb_file_per_table=0/1 (0是共享,1是独立)设置后只影响新建的表

设置表空间类型

innodb_file_per_table=0/1 —–>0是共享表空间，1是独立表空间

设置与否只影响新建的表。

共享表空间添加数据文件（火车上加车厢）。

默认情况下只有一个数据文件（火车上只有一个车厢，这个车厢不够可以自动扩展。）

    mysql> show variables like ‘%file_path%’;

    +———————–+————————+

    | Variable_name | Value |

    +———————–+————————+

    | innodb_data_file_path | ibdata1:12M:autoextend |

正确的例子：

innodb_data_file_path=ibdata1:76M;ibdata2:50M:autoextend

Innodb事务
事务简介

为了数据安全出现的一个特性

数据本身的安全（物理安全、在不在、有没有）

数据逻辑的安全（误删、误修改、错误的业务逻辑）

事务理论上的功能

一组数据操作执行步骤，这些步骤被视为一个工作单元

用于对多个语句进行分组

可以在多个客户机并发访问同一个表中的数据时使用

所有步骤都成功或都失败

如果所有步骤正常，则执行

如果步骤出现错误或不完整，则取消

事务伴随着”交易”出现的数据库概念

我们理解的”交易”是什么？

    物与物的交换（古代）

    货币现金与实物的交换（现代1）

    虚拟货币与实物的交换（现代2）

    虚拟货币与虚拟实物交换（现代3）

    绝对不会出现，货币与空交换（？？）

    数据库中的”交易”是什么？

        事务又是如何保证”交易”的”和谐”？

ACID

成功事务：

    1)、开始事务：start transaction / begin

    2)、执行事务语句（DML，不包含查询类的,update\delete\create）

    3)、事务完成：commit

不成功的事务：

    1)、开始事务：start transaction / begin

    2)、执行事务语句（DML，不包含查询类的,update\delete\create）

    3)、人为反悔或者中间过程失败，rollback

 

隐式commit事务语句

    如果执行了DDL\DCL 、start transaction 或开启autocommit=1的功能，都会自动触发commit

autocommit=1/0        是否开启自动提交功能，

        1代表开启，每条事务语句完成之后都自动提交。

        0代表关闭的。

        set autocommit=0 临时的

        vi /etc/my.cnf 永久的

            autocommit=0

事务的ACID是怎么保证的?
D：持久化

如果每次事务完成都写磁盘,IO将成为瓶颈。所以数据库推出一个理念WAL。

redo：记录内存数据页的变化。首先记录到了内存中redo buffer page。

WAL：write ahead log。

A、C：原子性和一致性

Redo+Undo

I：隔离性

锁和隔离级别