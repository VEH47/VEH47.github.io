---
title: "Mysql MHA高可用扩展 Atlas读写分离(十)"
date: 2019-09-29T18:08:15+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
Mysql MHA高可用扩展 Atlas读写分离
<!--more-->
MHA高可用扩展 (binlog server)

前提：

企业中有专门的一台机器作为binlog server。存储设备和网络带宽 越快越好

这台机器上需要有mysql，而且必须开启gtid。5.6以上版本

配置binlog接收节点

binlog server

（1）准备一台新的mysql实例，必须开启GTID

（2）建立binlog接收目录，不能和主库binlog目录一样

mkdir /data/mysql/binlog/

chown -R mysql.mysql /data//mysql/binlog/


（3）在app1.cnf(也就是manage的配置文件)中开启binlogserver功能

[binlog1]

no_master=1

hostname=10.0.0.53             ——>用于作为binlog server那台机器

master_binlog_dir=/data/mysql/binlog/     ——>我们自定义的binlog保存目录

（4）开启binlog接收（接收主库的binlog）

cd /data/mysql/binlog/

mysqlbinlog -R –host=10.0.0.51 –user=mha –password=mha –raw –stop-never mysql-bin.000001 &

（5）停止MHA

/usr/bin/masterha_stop –conf=/etc/mha/app1.cnf

（6）开启MHA

nohup masterha_manager –conf=/etc/mha/app1.cnf –remove_dead_master_conf –ignore_last_failover < /dev/null > /var/log/mha/app1/manager.log 2>&1 &

MHA其它参数

设置主库宕机后切换权重

[root@db05 /usr/local/bin]# vim /etc/mha/app1.cnf

例如把1节点设置权重

[server1]

hostname=10.0.0.51

port=3306

candidate_master=1 不管怎样都切到优先级高的主机，一般在主机性能差异的时候用

#设置为候选master，如果设置该参数以后，发生主从切换以后将会将此从库提升为主库，即使这个主库不是集群中事件最新的slave

check_repl_delay=0 不管优先级高的备选库，数据延时多久都要往那切

#默认情况下如果一个slave落后master 100M 的relaylogs的话，MHA将不会选择该slave作为一个新的master，因为对于这个slave的恢复需要花费很长时间，通过设置check_repl_delay=0,MHA触发切换在选择一个新的master的时候将会忽略复制延时，这个参数对于设置了candidate_master=1的主机非常有用，因为这个候选主在切换的过程中一定是新的master

注：

1、多地多中心，设置本地节点为高权重

2、在有半同步复制的环境中，设置半同步复制节点为高权重

3、你觉着哪个机器适合做主节点，配置较高的 、性能较好的

atlas读写分离

存在意义：提高数据库架构的性能

读性能：读写分离

写性能：分库分表、分片功能

atlas功能

1、上端是和前端的业务应用对接，后端是和数据库对接，所以把他称之为数据库”中间件”

2、他应该具备什么功能？

(1)应该能够被应用连接，而且应该像数据库一样被连接，应该提供类似mysql 连接层的功能 (连接命令、端口、用户、密码、地址)

(2)应该还具有，SQL层的基本功能：

接收SQL 判断语法 验证语义（SQL的类型）

读请求：落到从节点上运行

多个从节点，接收的读请求应该都是平均的

写请求：落到主节点上去进行

SQL黑白名单

（3）能够监控所有后端MySQL实例，以及实例是否能读能写

（4）在线增加删除数据库节点

（5）数据库节点失效，能够感知，自动剔除节点

atlas安装配置

    rpm -ivh Atlas-2.2.1.el6.x86_64.rpm

    /usr/local/mysql-proxy/bin/encrypt 123 —->制作加密密码

    cd /usr/local/mysql-proxy

    [root@db05 /usr/local/mysql-proxy]# ll

    total 16

    drwxr-xr-x 2 root root 4096 Mar 2 10:29 bin

    drwxr-xr-x 2 root root 4096 Mar 2 13:02 conf

    drwxr-xr-x 3 root root 4096 Mar 2 10:29 lib

    drwxr-xr-x 2 root root 4096 Mar 2 10:50 log

    cd conf

    vim test.cnf

    [mysql-proxy]

    admin-username = user

    admin-password = pwd

    proxy-backend-addresses = 10.0.0.55:3306 虚拟ip

    proxy-read-only-backend-addresses = 10.0.0.51:3306,10.0.0.53:3306 从库设置只读

    pwds = repl:3yb5jEku5h4=,mha:O2jBXONX098= 复制用户及其的密码

    daemon = true

    keepalive = true

    event-threads = 8

    log-level = message

    log-path = /usr/local/mysql-proxy/log 日志路径

    sql-log=ON

    proxy-address = 0.0.0.0:33060

    admin-address = 0.0.0.0:2345

    charset=utf8

启动atlas

    /usr/local/mysql-proxy/bin/mysql-proxyd test start

    ps -ef |grep proxy

测试
读的测试

    [root@db05 /usr/local/mysql-proxy]# mysql -umha -pmha -h 10.0.0.53 -P 33060

配置文件里的用户

    mysql> show variables like “%server_id%”;

    +—————-+——-+

    | Variable_name | Value |

    +—————-+——-+

    | server_id | 21 | 从库的server id

    | server_id_bits | 32 |

    +—————-+——-+

    2 rows in set (0.01 sec)

    mysql> show variables like “%server_id%”;

    +—————-+——-+

    | Variable_name | Value |

    +—————-+——-+

    | server_id | 22 | 从库的server id

    | server_id_bits | 32 |

    +—————-+——-+

写的测试

主节点创建测试用户

    mysql> grant create ,insert,update,delete ,select ,drop on *.* to app@’10.0.0.%’ identified by ‘123’;

设置两个从节点只读

    set global read_only=1;

在atlas管理点连接测试

    mysql -uapp -p123 -h10.0.0.53 -P33060 链接到了主节点

    create database db1;

查看其他节点

    mysql> show databases;

    +——————–+

    | Database |

    +——————–+

    | information_schema |

    | db1 |

    | mysql |

    | performance_schema |

    | test |

    +——————–+

    5 rows in set (0.01 sec)

 

管理atlas
    mysql -uuser -ppwd -h127.0.0.1 -P2345

打印帮助：

    mysql> select * from help;

动态添加删除节点：

REMOVE BACKEND 3; 删除节点3

ADD SLAVE 10.0.0.10:3308;     添加节点

SAVE CONFIG; 提交

分库分表
表数据行超过800w行就做分表、分库

分表：将一个大表拆分为多个小表进行存储

自动分表
使用Atlas的分表功能时，首先需要在配置文件test.cnf设置tables参数。

tables参数设置格式：数据库名.表名.分表字段.子表数量，

比如：

你的数据库名叫school，表名叫stu，分表字段叫id，总共分为2张表，

那么就写为school.stu.id.2，如果还有其他的分表，以逗号分隔即可。

用户需要手动建立2张子表（stu_0,stu_1，注意子表序号是从0开始的）。

所有的子表必须在DB的同一个database里。

当通过Atlas执行（SELECT、DELETE、UPDATE、INSERT、REPLACE）操作时，Atlas会根据分表结果（id%2=k），定位到相应的子表（stu_k）。例如，执行select * from stu where id=3;，Atlas会自动从

stu_1这张子表返回查询结果。但如果执行SQL语句（select * from stu;）时不带上id，则会提示执行stu

表不存在。

Atlas暂不支持自动建表和跨库分表的功能。

Atlas目前支持分表的语句有SELECT、DELETE、UPDATE、INSERT、REPLACE。

例

stu 表 1000w数据 , id name

规划三张表

问

怎么比较均匀存到3张表中?

range(范围):

1-3333333                 表1

3333334-6666666                表2

6666667-10000000             表3

以上分表方式,存数据非常均匀,取数据不均与,因为要考虑业务需求

如果业务查询热点数据集中在id是1-200w这些数据,那么读取就不均匀

取模分表

n/3 取余数 (0,1,2)

(1)如果是 0 则分到 stu_0

(2)如果是 1 则分到 stu_1

(3)如果是 2 则分到 stu_2

1-200w是热点数据

取余数

select id ,name from stu where id=10

配置文件

    vi /usr/local/mysql-proxy/conf/test.cnf

    tables = school.stu.id.3

重启atlas

/usr/local/mysql-proxy/bin/mysql-proxyd test restart

(主库)手工创建,分表后的库和表,分别为定义的school 和 stu_0 stu_1 stu_2

    create database school;

    use school

    create table stu_0 (id int primary key,name varchar(20));

    create table stu_1 (id int primary key,name varchar(20));

    create table stu_2 (id int primary key,name varchar(20));

测试:

    mysql> insert into stu values (3,’wang5′);

    mysql> insert into stu values (2,’li4′);

    mysql> insert into stu values (1,’zhang3′);

工具分表
工具分表：

range ：范围

hash：

取模（取余）：100行数据分到4个表，比如按照id（1-100）。

    id和4—>

    id=1，1/4 ,余数是1，应该放到编号为1的表

    id=2,…………2,…………….2

    id=3，。。。。。。。3.。。。。。。。3

    id=4,…………..0…………….

    ….

表：首先要准备好编号为0-3的表。

优势：比较简单，比较均匀

劣势：最怕的就是增加删除表

一致性hash：

也是一种取模的方式，id/2的32次方取模

分库（分片）：分布式系统

分布式的存储系统：

存储空间问题

并发访问问题

分布式的计算系统


IP过滤：client-ips

该参数用来实现IP过滤功能。

在传统的开发模式中，应用程序直接连接DB，因此DB会对部署应用的机器(比如web服务器)的IP作访问授权。

在引入中间层后，因为连接DB的是Atlas，所以DB改为对部署Atlas的机器的IP作访问授权，如果任意一台客户端都可以连接Atlas，就会带来潜在的风险。

client-ips参数用来控制连接Atlas的客户端的IP，可以是精确IP，也可以是IP段，以逗号分隔写在一行上即可。

如：

client-ips=192.168.1.2, 192.168.2，这就代表192.168.1.2这个IP和192.168.2.*这个段的IP可以连接Atlas，

其他IP均不能连接。

如果该参数不设置，则任意IP均可连接Atlas。

如果设置了client-ips参数，且Atlas前面挂有LVS，则必须设置lvs-ips参数，否则可以不设置lvs-ips。

SQL语句黑白名单

Atlas会屏蔽不带where条件的delete和update操作，以及sleep函数。

 Atlas-Sharding版本介绍*
Sharding的基本思想就是把一个数据表中的数据切分成多个部分, 存放到不

同的主机上去(切分的策略有多种), 从而缓解单台机器的性能跟容量的问题. sharding是一种水平切分, 适用于单表数据庞大的情景. 目前atlas支持静态的sharding方案, 暂时不支持数据的自动迁移以及数据组的动态加入.

Atlas以表为单位sharding, 同一个数据库内可以同时共有sharding的表和不sharding的表, 不sharding的表数据存在未sharding的数据库组中. 目前Atlas sharding支持insert, delete, select, update语句, 只支持不跨shard的事务. 所有的写操作如insert, delete, update只能一次命中一个组, 否则会报”ERROR 1105 (HY000):write operation is only allow to one dbgroup!”错误.

由于sharding取替了Atlas的分表功能, 所以在Sharding分支里面, Atlas单

机分表的功能已经移除, 配置tables将不会再有效.

Atlas-Sharding架构*


Sharding配置示例*
Atlas支持非sharding跟sharding的表共存在同一个Atlas中, 2.2.1之前的配置可以直接运行. 之前的配置如proxy-backend-addresses = 192.168.0.12:3306 proxy-read-only-backend-addresses = 192.168.0.13:3306,192.168.0.14:3306 … 这配置了一个master和两个slave,

这属于非sharding的组, 所有非sharding的表跟语句都会发往这个组内. 所以之前没有Sharding的Atlas的表可以无缝的在新版上使用,

注意: 非Sharding的组只能配置一个, 而sharding的组可以配置多个. 下面的配置, 配置了Sharding的组, 注意与上面的配置区分

[shardrule-0]

table = test.sharding_test

#分表名，有数据库+表名组成

type = range

#sharding类型：range 或 hash

shard-key = id

#sharding 字段

groups = 0:0-999,1:1000-1999

#分片的group，如果是range类型的sharding，则groups的格式是：group_id:id范围。如果是hash类型的sharding，则groups的格式是：group_id。例如groups = 0, 1

[group-0]

proxy-backend-addresses=192.168.0.15:3306

proxy-read-only-backend-addresses=192.168.0.16:3306

[group-1]

proxy-backend-addresses=192.168.0.17:3306

proxy-read-only-backend-addresses=192.168.0.18:3306

Sharding测试案例*
创建测试表:

    DROP TABLE IF EXISTS `sharding_test`;

    CREATE TABLE `sharding_test` ( `id` int(11) NOT NULL AUTO_INCREMENT, `name`char(50)

    COLLATE utf8_bin NOT NULL, `age` int(11) DEFAULT NULL, `birthday` date DEFAULT NULL,`nickname` char(50) COLLATE utf8_bin DEFAULT NULL, PRIMARY KEY (`id`) )

    mysql -h127.0.0.1 –P33060 -uroot -pmysqltest –c

    mysql> use test;

    mysql> insert into sharding_test(id, name, age) values(1, ‘test’, 0);

    mysql> insert into sharding_test(id, name, age) values(50, ‘test’, 0), (999, ‘test’, 0);

注意：

以上几条数据都插入到了dbgroup0,

请注意第二条多值插入的语句, 因为50和999都命中了dbgroup0, 所以其执行成功, 但是如果执行以下的语句:

    mysql> insert into sharding_test(id, name, age) values(100, ‘test’, 0), (1500, ‘test’, 0);

    ERROR 1105 (HY000): Proxy Warning – write operation is only allow to one dbgroup!

在sharding的表中, 这是不允许的, 因为id为100命中了dbgroup0, 而id为1500 命中了dbgroup1, 由于分布式的多值插入可能导致部分成功, 需要回滚, 这个Atlas暂不支持. update, delete, replace同理.

测试完成分别登陆两个主库进行查看数据。

Sharding限制
关于支持的语句

Atlas sharding只对sql语句提供有限的支持, 目前支持基本的Select, insert/replace, delete, update语句, 支持全部的Where语法(SQL-92标准), 不支持DDL(create drop alter)以及一些管理语句, DDL请直连MYSQL执行, 请只在Atlas上执行Select, insert, delete, update(CRUD)语句.

对于以下语句, 如果语句命中了多台dbgroup, Atlas均未做支持(如果语句只命中了一个dbgroup, 如select count(*) from test where id < 1000, 其中dbgroup0范围是0 – 1000, 那么这些特性都是支持的)

Limit Offset(支持Limit)

Order by

Group by

Join

ON

Count, Max, Min等函数

增加节点

注意: 暂时只支持range方式的节点扩展, hash方式由于需要数据迁移, 暂时未做支持.

扩展节点在保证原来节点的范围不改变的情况下, 如已有dbgroup0为范围0 – 999, dbgroup1为范围 1000- 1999, 这个时候可以增加范围>2000的节点. 如增加一个节点为2000 – 2999, 修改配置文件, 重启Atlas即可.