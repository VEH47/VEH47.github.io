---
title: "数据库DML和DQL和DCL语句及元数据(三)"
date: 2019-09-29T18:04:34+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
数据库DML和DQL和DCL语句及元数据
<!--more-->
DCL 数据控制 语句

**授权**

grant all on *.* to oldboy@’localhost’ identified by ‘oldboy123’;

给oldboy用户所有权限并设置密码

刷新用户权限

flush privileges；


**去除权限**

revoke drop on *.* from ‘test’@’10.0.0.%’; 收回test用户所有库drop(删除)权限

revoke all on *.* from test@’10.0.0.%’ 收回test用户所有库的所有权限

**DML 数据操作语句 功能,对标的行信息进行操作(增,删,改)**

insert into 给表的列中插入内容

insert into cm(id,name) values(1,’hkx’); 给id name这两列插入1 hkx这两个内容

insert into test(name) values(‘oldgirl’); 给test表的name列插入oldgirl内容

insert into test values(3,’inca’); 给test表的两列分别加入3,inca(也就是是一行)这两个数据(这里只有两列,如果还有其他列,后边的values的值就得继续添加)

insert into test values(4,’zuma’),(5,’kaka’); 给test表插入两行内容

delete from test; 删除test表所有数据

inster into test values (1,’oldboy’),(2,’oldgirl’),(3,’inca’),(4,’zuma’),(5,’kaka’); 给test表插入五行数据

update 修改表内容
update tt set name=’old’ where id=11

把id列的11的那一行name列的内容修伽为old(id列的11行和name列交叉处修改)

删除表中数据

1.一定要where条件

2.伪删除（让业务觉得数据不在了），通过状态列（Enum（1,0））

delete from tt WHERE id=11;

把表中数据排序

use world

show tables;

select * from city;

create table tt (id int ,name VARCHAR(20));

insert into tt values (11,’oldboy’),(21,’oldgirl’),(3,’inca’),(4,’zuma’),(5,’kaka’);

select* from tt order by id

**DQL语句**

查看show delect

show databases; 查看有哪些库

show grants for root@’localhost’ 查看用户权限

show create database oldboy 查询如何创建oldboy这个库及其信息

show create database oldboy charset utf8; 查看创建oldboy库的属性

show grants for root@’localhost’ 查看用户权限

show table; 查看表

show create table cmcc; 查看表cmcc

desc cmcc; 查看表cmcc的有哪些列及列定义

select database(); 查看当前所在数据库，类似于pwd命令的功能

select user(); 查看当前登录数据库的用户，类似于whoami命令

show tables； 查看数据库中表信息

select * from user\G; 查看user表中所有信息，并且纵行显示

select user,host from user; 查看user表中指定信息，并且横行显示

select user,host from mysql.user; 查看哪些用户可以登录及管理mysql数据库

show charset; 查看所有字符集

select table_schema,count(table_name) from tables group by table_schema; 统计有多少表

select * from tt order by id 查看tt表并排序

**where 条件**

建议使用的：= < > like ‘hang%’ and 求交集

不建议使用：or —替换为–> union xor not !=

order by 排序

数字列进行排序（某东：价格字段），排序列一般情况下都有索引

limit 结果集限制

以上两种一般一起使用

语法: limit 跳过的行数, 要取多少行

聚合操作

union 去重复

union all 不去重

第一个场景: 横向分表

需要查询多表信息的

select* from t1

union

select* from t2

union

select* from t3

第二个场景：替代or功能

select * from city

where countrycode=’chn’

or

countrycode=’JPN’

select * from city

where countrycode=’chn’

uniot all

select * from city

where countrycode=’JPN’

join表连接 用来连接的前表或者后表的列必须都有索引

多表连接查询

连接（join）：将一张表中的行按照某个条件（连接条件）和另一张表中的行连接起来形成一个新行的过程叫做连接

例1：natural join子句

自动到两张表中查找所有同名同类型的列拿来做连接列，进行相等连接

select name,countrycode ,language,population from city natural join countrylanguage where population > 1000000 order by population;

连接列是population，并且在select子句只能出现一个连接列

例2：使用using子句

selectname,countrycode ,language ,population from city join countrylanguage using(countrycode);

例3：传统的连接写法

select name,ci.countrycode ,cl.language ,ci.population from city ci , countrylanguage ci where ci.CountryCode=cl.countrycode;

注意：一旦给表定义了别名，那么原始的表名就不能在出现在该语句的其它子句中了

not null default 非空 默认值配合
create table asd (id int auto increment primary key,name varchar(20) not null default ‘小狗‘);


默认值

desc asd

select * from asd

insert into asd values(1,’小明‘);

insert into asd(id) values(2);

unique

数据库数据的分类
行数据信息

元数据：

表的定义信息（frm）

数据库状态信息

对象属性信息

tables表
例

select table_schema,count(table_name) from tables group by table_schema;

select table_schema,table_name,engine from tables where engine=’innodb’;

select table_schema,table_name,engine from tables where engine=’myisam’;

select table_schema,table_name,column_name ,data_type from columns where DATA_TYPE like ‘enum’;

select table_name ,engine from tables where table_schema=’world’;

备份语句：

mysqldump -uroot -p123 oldboy test > /bakcup/oldboy_test.sql

mysqldump -uroot -p123 oldboy t1 > /bakcup/oldboy_t1.sql

select concat(“mysqldump -uroot -p123 “,table_schema,” “,table_name ,”>/backup/”,table_schema,”_”,table_name,”.sql”) from information_schema.tables into outfile’/tmp/bakcup.sh’

将数据库下的所有表都备份

show tables FROM <database_name>：列出指定数据库中的表

show COLUMNS FROM <table_name>：显示表的列结构

show INDEX FROM <table_name>：显示表中有关索引和索引列的信息

show CHARACTER SET：显示可用的字符集及其默认整理

show COLLATION：显示每个字符集的整理

show STATUS：列出当前数据库状态

show status like ‘innodb%’;

show status like ‘%lock%’

show processlist;

show VARIABLES：列出数据库中的参数定义值