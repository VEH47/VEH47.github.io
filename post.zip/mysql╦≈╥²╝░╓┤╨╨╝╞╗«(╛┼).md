---
title: "Mysql索引及执行计划(九)"
date: 2019-09-29T18:06:53+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
Mysql索引及执行计划
<!--more-->
索引作用

影响对表数据的操作(select update delete)

设计理念

索引好比目录,让你更快找到想要的东西,让获取的数据更有目的性,从而提高数据库检索数据的性能 , 比较类似于linux操作系统的inode

索引的类型

BTREE:B+树索引

HASH：HASH索引

FULLTEXT：全文索引

RTREE：R树索引

索引管理

索引分为主键索引, 唯一索引, 普通索引

添加普通索引
use world

create table test (id int not null varchar(20));

添加普通索引: alter table test add index id_idx(id);

删除普通索引:alter table test drop index id_idx;

select id,name from test where state=1 order by id group by name;

用索引查询,加上条件,查询所读更快

主键索引

一般选择或添加一个自增长 唯一 非空的列作为主键列, 添加主键一般在创建表时就添加主键索引

alter table test change id id int(4) primary key not null auto_increment;(primary key 主键必须
建表后添加的)

create table test (id int(4) not null auto_increment, name char(20) not null, primary key (id)) engine=innodbdefault charset=utf8;

唯一索引 内容唯一，但不是主键

唯一键: alter table test add unique index name_idx(id);(unique唯一键)

create unique index index_name on test(name);

前缀索引根据字段的前N个字符建立索引

alter table test add index name_idx(name(8));

create index index_name on test(name(8));

复合索引(explain 查看索引情况)

create table t1 (id int,name varchar(20),age int,sex enum(‘m’,’f’),money int);

alter table t1 add index t1_idx(money,age,sex);

desc t1 注意这里创建索引列的顺序

show index from t1

走索引的情况：

explain select name,age,sex,money from t1 where money=30 and age=30 and sex=’m’;

explain select name,age,sex,money from t1 where money=30 and age=30 ;

使用条件时的顺序

部分走索引

explain select name,age,sex,money from t1 where money=30 and sex=’m’;

有一半的顺序正确

不走索引的：

explain select name,age,sex,money from t1 where age=20 顺序不正确

explain select name,age,sex,money from t1 where age=30 and sex=’m’;

explain select name,age,sex,money from t1 where sex=’m’;

mysql> explain select name,age,sex,money from t1 where money=30 and age=30 and sex=’m’;

获取适合做索引的列
select count(*) from mysql.user; ———->4行

select count(distinct user) from mysql.user; —–>3行，说明可定有一个重复行

select count(distinct user,host) from mysql.user; 4行，两个条件就没有重复行了，更适合做索引条件
统计
不重复的

不走索引及创建索引的规范

数据库索引设计原则

1．选择唯一性索引

唯一性索引的值是唯一的，可以更快速的通过该索引来确定某条记录。

例如，学生表中学号是具有唯一性的字段。为该字段建立唯一性索引可以很快的确定某个学生的信息。如果使用姓名的话，可能存在同名现象，从而降低查询速度。

2．为经常需要排序、分组和联合操作的字段建立索引

经常需要ORDER BY、GROUP BY、distinct和UNION等操作的字段，排序操作会浪费很多时间。如果为其建立索引，可以有效地避免排序操作。

3．为常作为查询条件的字段建立索引

如果某个字段经常用来做查询条件，那么该字段的查询速度会影响整个表的查询速度。因此，为这样的字段建立索引，可以提高整个表的查询速度。

4．尽量使用前缀来索引

如果索引字段的值很长，最好使用值的前缀来索引。例如，TEXT和BLOG类型的字段，进行全文检索会很浪费时间。如果只检索字段的前面的若干个字符，这样可以提高检索速度。

5．限制索引的数目

索引的数目不是越多越好。每个索引都需要占用磁盘空间，索引越多，需要的磁盘空间就越大。修改表时，对索引的重构和更新很麻烦。越多的索引，会使更新表变得很浪费时间。

6．尽量使用数据量少的索引

如果索引的值很长，那么查询的速度会受到影响。例如，对一个CHAR（100）类型的字段进行全文检索需要的时间肯定要比对CHAR（10）类型的字段需要的时间要多。

7．删除不再使用或者很少使用的索引

表中的数据被大量更新，或者数据的使用方式被改变后，原有的一些索引可能不再需要。数据库管理员应当定期找出这些索引，将它们删除，从而减少索引对更新操作的影响。

8.小表不应建立索引

9、包含大量的列并且不需要搜索非空值的时候可以考虑不建索引

不走索引

1) 没有查询条件，或者查询条件没有建立索引

select * from tab; 全表扫描。在业务数据库中，特别是数据量比较大的表。

是没有全表扫描这种需求

1、对用户查看是非常痛苦的。

2、对服务器来讲毁灭性的。

例:

（1）select * from tab

SQL改写成以下语句：

selec * from tab order by price limit 10 需要在price列上建立索引,只显示10行

（2）

select * from tab where name=’zhangsan’ name 列没有索引

改：

1、换成有索引的列作为查询条件

2、将name列建立索引

2) 查询的数量是大表的大部分，应该是30％以上。

查询的结果集，超过了总数行数30%，优化器觉得就没有必要走索引了。

假如：tab表 id，name id:1-100w

select * from tab where id>700000

怎么改写

结合业务判断，有没有更好的方式。如果没有更好的改写方案

尽量不要在mysql存放这个数据了。放到redis里面。

3) 索引本身失效，统计数据不真实

索引有自我维护的能力。对于表内容变化比较频繁的情况下，有可能会出现索引失效。

4) 查询条件使用函数在索引列上，或者对索引列进行运算，运算包括(+，-，*，/，! 等)

例子：

错误的例子：select * from test where id-1=9;

正确的例子：select * from test where id=10;

5)隐式转换导致索引失效.这一点应当引起重视.也是开发中经常会犯的错误.

由于表的字段tu_mdn定义为varchar2(20),但在查询时把该字段作为number类型以where条件传给数据库,(字符串要用引号)这样会导致索引失效.

错误的例子：select * from test where tu_mdn=13333333333;

正确的例子：select * from test where tu_mdn=’13333333333′;

6) <> ，not in 不走索引

explain select * from teltab where telnum <> ‘110’;

explain select * from teltab where telnum not in(‘110′,’119’);

单独的>,<,in 有可能走，也有可能不走，和结果集有关

or或in 尽量改成union

explain select * from teltab where telnum in (‘110′,’119′);

改写成：

explain select * from teltab where telnum=’110′

union all

select * from teltab whereE telnum=’119’

7) like “%_” 百分号在最前面不走

explain select* from teltab whereE telnum LIKE ‘31%’ 走range索引扫描

explain select * from teltab whereE telnum LIKE ‘%110’ 不走索引

8) 单独引用复合索引里非第一位置的索引列.

例 复合索引：

create table t1 (id int,name varchar(20),age int ,sex enum(‘m’,’f’),money INT);

alter table t1 ADD INDEX t1_idx(money,age,sex);

DESC t1

SHOW INDEX from t1

走索引的情况测试：

explain select name,age,sex,money from t1 where money=30 and age=30 and sex=’m’;

explain select name,age,sex,money from t1 where money=30 and age=30 ;

explain select name,age,sex,money from t1 where money=30 and sex=’m’; 部分走索引

不走索引的：

explain select name,age,sex,money from t1 where age=20

explain select name,age,sex,money from t1 where age=30 and sex=’m’;

explain select name,age,sex,money from t1 where sex=’m’;

1) CBO（基于成本的优化器）计算走索引花费过大的情况。其实也包含了上面的情况，这里指的是表占有的block要比索引小。

2) B-tree索引 is null不会走,is not null会走,位图索引 is null,is not null 都会走

3) 联合索引 is not null 只要在建立的索引列（不分先后）都会走, in null时 必须要和建立索引第一列一起使用,当建立索引第一位置条件是is null 时,其他建立索引的列可以是is null（但必须在所有列 都满足is null的时候）,

或者=一个值； 当建立索引的第一位置是=一个值时,其他索引列可以是任何情况（包括is null =一个值）,

以上两种情况索引都会走。其他情况不会走。

4)BLOB 和TEXT 类型的列只能创建前缀索引；

5)MySQL 目前不支持函数索引；

6)Join 语句中Join 条件字段类型不一致的时候MySQL 无法使用索引；

例

这条语句慢：

select name from country where name like ‘c%’ limit 10;

desc country； —>看表结构发现没有创建索引

explain select name from country where name like ‘c%’ limit 10; —看执行计划

possible_keys key Extra

没有索引或者没走索引。

发现没走索引

创建索引

适不适合？

select count(*) from country; ——>239

select count(distinct name ) from country; —>239

经过判断可以建立索引

alter table country add index name_idx(name)

explain select name from country where name like ‘c%’ limit 10;