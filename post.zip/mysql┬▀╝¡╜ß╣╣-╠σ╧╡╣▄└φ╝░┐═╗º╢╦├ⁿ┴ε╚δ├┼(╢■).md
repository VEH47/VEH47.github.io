---
title: "Mysql逻辑结构 体系管理及客户端命令入门(二)"
date: 2019-09-29T18:03:58+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
mysql逻辑结构
mysql中含有多个库(database或scheme), 每个库中含有多个表(table), 表中含有行:(数据行, 将来需要获取的数据), 列定义: (1)数据的含义(列名字), (2)数据的约束(数据的类型, 特殊属性, 非空, 唯一等)
<!--more-->

表空间
表空间也就是数据文件

performance_schema 辅助优化的视图库（默认情况没开启）

information_schema 查询元数据的视图库（虚拟的，操作系统层面看不见）

    [root@db03 /application/mysql/data]# ll

    total 110624

    -rw-rw—- 1 mysql mysql 56 Feb 2 16:31 auto.cnf

    -rw-rw—- 1 mysql mysql 5253 Feb 5 10:47 db03.err

    -rw-rw—- 1 mysql mysql 5 Feb 5 11:59 db03.pid

    -rw-rw—- 1 mysql mysql 12582912 Feb 5 16:35 ibdata1 共享表空间数据文件

    -rw-rw—- 1 mysql mysql 50331648 Feb 5 16:35 ib_logfile0 日志文件（redo日志

    -rw-rw—- 1 mysql mysql 50331648 Feb 2 16:27 ib_logfile1

    drwx—— 2 mysql mysql 4096 Feb 2 16:27 mysql 系统的验证相关的库(user.frm 表

    drwx—— 2 mysql mysql 4096 Feb 5 16:35 oldboy 结构定义文件 user.MYD 数据

    drwx—— 2 mysql mysql 4096 Feb 2 16:27 performance_schema 文件 user.MYI 索

    drwx—— 2 mysql mysql 4096 Feb 5 16:21 world 引文件)

mysql数据库基础管理

mysql客户端连接

mysql -u+数据库用户名 –p+密码 –h+连接的ip -P+端口 –S+socket文件

设定密码: mysqladmin –uroot –p password 123

修改密码: mysqladmin –uroot –p123 password 456

数据库的启动方式

启动过程：

（1）启动后台进程（mysqld）

（2）分配线程

（3）预分配内存空间

（4）加载数据文件

启动方式

1)bin/mysqld_safe & —启动mysqld的脚本—> mysqld

通过safe启动调动mysqld启动脚本启动mysqld

2)cp mysql.server /etc/init.d/mysqld

/etc/init.d/mysqld start —-> bin/mysqld_safe & –> mysqld

通过启动复制的脚本调动safe文件在启动msyqld

msyql守护进程

启动实例时需要解决的问题

(1)在编译时，硬编码他需要的预设信息到程序里面（mysqld_safe）

(2) 在命令行上直接直接指定想要的预设配置（可以得出额外信息，命令行优先于预编译的配置）

/application/mysql/bin/mysqld_safe –basedir=/application/mysql –datadir=/application/mysql/data/ –socket=/tmp/aa.txt &

(3)配置文件，减轻命令行的重复性的配置选项(配置文件的优先级高于编译的，但优先级低于命令行)。

    [mysqld_safe]或者[mysqld]

    basedir=/application/mysql

    datadir=/application/mysql/data/

    socket=/tmp/aa.txt

配置文件的构成
1)标签项：[程序项]:mysql给我们提供的程序

1、服务端（影响了mysql的启动）

2、客户端的（影响了mysql客户端连接）

2)针对标签项设置的Options（参数）这些选项是和标签项的支持的命令行选项有关

3)配置文件的标签类型

服务端：

    [mysqld]

    [mysqld_safe]

    [server]

客户端：

    [mysql]

    [mysqldump]

    [mysqladmin]

    [client]

如果基于配置文件顺序的话

⑴/etc/my.cnf ⑵/etc/mysql/my.cnf ⑶ $MYSQL_HOME/my.cnf ⑷~/.my.cnf ⑸ –defaults-extra-file

但是，如果在命令行启动时，加入了–defaults-file,配置文件就会跳过

总结:mysqld启动优先级顺序,

    1)命令行优先级最高
    2)defaults-file
    3)/etc/my.cnf /etc/mysql/my.cnf $MYSQL_HOME/my.cnf ~/.my.cnf –defaults-extra-file 
    4)预编译配置

配置文件案例
    [root@db03 ~]# vim /etc/my.cnf

    [mysqld] 服务端标签

    basedir=/application/mysql 服务

    datadir=/application/mysql/data 各个文件

    server-id=20

    port=3306    端口

    log-bin=/data/mysql/mysql-bin

    socket=/tmp/mysql.sock    服务端启动的socket文件

    log-error=/var/log/mysql.log    日志文件

    [root@db03 ~]# mkdir -p /data/mysql/

    [root@db03 ~]# chown -R mysql.mysql /data/mysql

    [root@db03 ~]# /etc/init.d/mysqld restart

多实例配置(端口分别是3306 3307 3308)
多个mysqld 进程（mysqld_safe）

多个配置文件(port server_id datadir log-error log-bin socket)

管理多套数据（多个数据目录，分别初始化数据）

创建实例目录

    [root@db03 ~]# mkdir -p /data/3306/data

    [root@db03 ~]# mkdir -p /data/3307/data

    [root@db03 ~]# mkdir -p /data/3308/data

配置文件

    [root@db03 ~]# vim /data/3306/my.cnf

    [mysqld]

    basedir=/application/mysql

    datadir=/data/3306/data

    server-id=3306

    port=3306

    log-bin=/data/3306/mysql-bin

    socket=/data/3306/mysql.sock

    log-error=/data/3306/mysql.log

    [root@db03 ~]# vim /data/3307/my.cnf

    [mysqld]

    basedir=/application/mysql

    datadir=/data/3307/data

    server-id=3307

    port=3307

    log-bin=/data/3307/mysql-bin

    socket=/data/3307/mysql.sock

    log-error=/data/3307/mysql.log

    [root@db03 ~]# vim /data/3308/my.cnf

    [mysqld]

    basedir=/application/mysql

    datadir=/data/3308/data

    server-id=3308

    port=3308

    log-bin=/data/3308/mysql-bin

    socket=/data/3308/mysql.sock

    log-error=/data/3308/mysql.log

授予目录权限

    [root@db03 ~]# chown -R mysql.mysql /data/

初始化数据

    [root@db03 ~]# cd /application/mysql/scripts

    [root@db03 /application/mysql/scripts]#./mysql_install_db –defaults-file=/data/3306/my.cnf –basedir=/application/mysql –datadir=/data/3306/data –user=mysql

    [root@db03 /application/mysql/scripts]#./mysql_install_db –defaults-file=/data/3307/my.cnf –basedir=/application/mysql –datadir=/data/3307/data –user=mysql

    [root@db03 /application/mysql/scripts]#./mysql_install_db –defaults-file=/data/3308/my.cnf –basedir=/application/mysql –datadir=/data/3308/data –user=mysql

启动实例

    [root@db03 ~]# /application/mysql/bin/mysqld_safe –defaults-file=/data/3306/my.cnf &

    [root@db03 ~]# /application/mysql/bin/mysqld_safe –defaults-file=/data/3307/my.cnf &

    [root@db03 ~]# /application/mysql/bin/mysqld_safe –defaults-file=/data/3308/my.cnf &

查看

    [root@db03 ~]# netstat -lntup|grep 330

    tcp 0 0 :::3306 :::* LISTEN 5648/mysqld

    tcp 0 0 :::3307 :::* LISTEN 5610/mysqld

    tcp 0 0 :::3308 :::* LISTEN 5174/mysqld

mysql用户管理
mysql用户的作用
1、用户登录 例如:mysqld mysqladmin mysqldump

2、用于管理数据库及数据 管理库 表 表结构 表行

mysql用户权限
对数据库的读、写等操作 （insert update、select等）

权限范围：全库级别： *.*

单库级别：oldboy.*

单表级别：oldboy.t1

用户的管理命令
创建删除用户
select user,host from mysql.user; 查看当前用户

create user ‘用户‘@’主机‘ identified by ‘密码‘; 创建用户

create user ‘oldboy’@’localhost’ identified by ‘oldboy123’;

drop user ‘user’@’主机域‘ 删除用户

企业里创建用户一般是授权一个内网网段登录，最常见的网段写法有两种。

方法1：172.16.1.%（%为通配符，匹配所有内容）。

方法2：172.16.1.0/255.255.255.0，但是不能使用172.16.1.0/24，是个小遗憾。

标准的建用户方法：

create user ‘web’@’172.16.1.%’ identified by ‘web123’;

 

查看用户对应的权限
show grants for oldboy@localhost\G

设定用户权限
grant 权限大小 on 权限范围 to 用户 [identified by ‘密码‘];

grant select on *.* to youndgirl@’localhost’ ;

方便的用法：

grant all on *.* to test@’10.0.0.%’ identified by ‘123’; 授予test所有库的所有权限

show grants for test@’10.0.0.%‘; 查看test权限

revoke drop on *.* from ‘test’@’10.0.0.%’; 收回test所有库drop(删除)权限

revoke all on *.* from test@’10.0.0.%‘ 收回test所有库的所有权限

grant SELECT, INSERT, UPDATE, DELETE, CREATE on app.* to app@’10.0.0.5%’ identified by ‘123’; 授予app用户对app库的这些权限

flush privileges; 刷新用户权限

当给一个用户授予多次权限, 以最大权限为准

mysql基础命令
mysql基础命令
mysql：

– 用于数据库连接管理

– 将 用户SQL 语句发送到服务器

• mysqladmin：

– 命令行管理工具

• mysqldump：

– 备份数据库和表的内容

mysql命令
非交互式获得库

    [root@db03 ~]# mysql -uroot -poldboy123 -S /tmp/mysql.sock -e “show databases”

    Warning: Using a password on the command line interface can be insecure.

    +——————–+

    | Database |

    +——————–+

    | information_schema |

    | mysql |

    | oldboy |

    | performance_schema |

    | world |

管理数据库的命令
接口自带功能及source命令
1、\h 或 help 或 ?

2、\G

3、\T 或 tee

4、\c 或 CTRL+c

5、\s 或 status

6、\. 或 source

7、\u 或use

使用 SOURCE 命令：

    mysql> SOURCE /data/mysql/world.sql

或者使用非交互式：

    mysql</data/mysql/world.sql

DDL:数据定义命令
database 或者schema 定义

create database oldboy; 创建新的库oldboy

create database oldboy charset utf8; 创建新的库oldboy并定义字符集

drop database oldboy; 删除oldboy库

alter database oldboy charset gbk; 修改oldboy库的字符集属性

create user youndgirl@’localhost’ identified by ‘oldboy123’ 创建用户并设置密码

drop user ‘oldboy’@’localhost’; 删除oldboy用户

delete from mysql.user where user=’oldboy’ and host=’localhost 特殊的删除用户方法

table定义(创建表)


表名字:ti


列定义: 列名
数据类型
约束(非空
唯一
主键
特殊属性)


存储引擎

    create table stu (id int,stu_name varchar(20),

    age int,sex enum(‘m’,’f’));

    create table cmcc (telnum int primary key,

    cname varchar(20),

                        idcard varchar(18)

                        not null unique);

    create table cmcc1 (telnum int primary key,

    cname varchar(20),

                        idcard varchar(18) not null unique )

                        engine=innodb;

    drop table cmcc; 删除cmcc表

    show create table cmcc; 查看表cmcc

    desc cmcc; 查看表cmcc的列定义

    alter table cmcc rename to com; 修改表名,把表cmcc修改为com

    alter table stu add address varchar(30) not null; 在表的最后加一列

    alter table stu add telnum int not null after stu_name; 在表的一列后边添加

    alter table stu add pid int not null first; 在表的第一列添加

生产中修改表结构

1. 备份和生产表一样表结构
的备用表

create table stu_bak like stu;

2. 按需求删除yy这一列

alter table stu_bak drop yy;

3. 将原表数据,除了yy列之外的数据倒入bak表中(业务需要停止)

inset into stu_bak select id,stu_name,telnum,oldboyage,sex,address,qq from stu;

4.确认新表旧表数据一致,重命名原表,将bak表重命名为原标

alter table stu rename stu_old;

alter table stu_bak rename stu;

select show(查询语句)

show databases; 查看有哪些库

show create database oldboy 查询如何创建oldboy这个库及其信息

show create database oldboy charset utf8; 查看创建oldboy库的属性

select database(); 表示查看当前所在数据库，类似于pwd命令的功能

select user(); 查看当前登录数据库的用户，类似于whoami命令

show tables；
查看数据库中表信息

select * from user\G; 查看user表中所有信息，并且纵行显示

select user,host from user; 查看user表中指定信息，并且横行显示

select user,host from mysql.user;

查看可以登录mysql数据库的目录,以及那些用户可以管理mysql数据库