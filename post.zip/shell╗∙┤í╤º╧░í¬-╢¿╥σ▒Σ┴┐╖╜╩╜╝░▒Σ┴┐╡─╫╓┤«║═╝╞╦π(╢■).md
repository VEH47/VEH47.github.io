---
title: "Shell基础学习—定义变量方式及变量的字串和计算(二)"
date: 2019-09-29T17:15:42+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
定义变量方式及变量的字串和计算
<!--more-->
实现变量交互
用交互式变量实现输入卡号密码

read定义交互变量 -p实现交户输入 -s 实现不出现返回值(用于密码)-t实现超时退出

    [root@node3 /server/scripts]# cat hkx.sh
    #!/bin/bash
    read -p “请输入你的卡号: ” number
    read -s -p “请输入你的密码: ” passwd
    echo
    echo “你的卡号为: $number” “你的密码为: $passwd”
--------
    [root@node3 /server/scripts]# sh hkx.sh
    请输入你的卡号: 123456789
    请输入你的密码:
    你的卡号为: 123456789 你的密码为: 951753

使用交互脚本修改主机名

    [root@node3 /server/scripts]# cat /root/modify_ip_hostname.sh
    #!/bin/bash
    ##############################################################
    # File Name: shiyan.sh
    # Version: V1.0
    # Author: Eleven
    # Organization: 2415069806
    # Created Time : 2018-01-25 15:28:03
    # Description:
    ###########################################################
    read -p “请输入你所需要设置的ip的外网地址: ” IP_eth0
    [ -z “$IP_eth0” ] && exit || echo ok
    read -p “请输入你所需要设置的ip的内网地址: ” IP_eth1
    [ -z “$IP_eth1” ] && exit || echo ok
    read -p “你所需要修改的主机名: ” name
    [ -z “$name” ] && exit || echo ok
    echo 修改后的IP:eth0:$IP_eth0 eth1:$IP_eth1 修改后的主机名:$name
    hostnamectl set-hostname $name
    local_ip_0=$(hostname -I |awk -F ‘[ ]’ ‘{print $1}’)
    local_ip_1=$(hostname -I |awk -F ‘[ ]’ ‘{print $2}’)
    sed -i “s#$local_ip_0#$IP_eth0#g” /etc/sysconfig/network-scripts/ifcfg-eth0 && sed -i “s#$local_ip_1#$IP_eth1#g” /etc/sysconfig/network-scripts/ifcfg-eth1
    reboot

变量的字串
计算字符串长度

    [root@node3 /server/scripts]# unset a

    [root@node3 /server/scripts]# a=`uuidgen`

    [root@node3 /server/scripts]# echo $a

    80d1769a-769e-4eca-8d80-9bd6ba49ea76

    [root@node3 /server/scripts]# echo ${#a}

    36

提取前几位字符

    [root@node3 /server/scripts]# echo ${a:10} 把第十位之后提取出(把前十位取出后的结果)
    69e-4eca-8d80-9bd6ba49ea76
从第一个字符开始,提取前十位,字符数序从0开始
    [root@node3 /server/scripts]# echo ${a:0:10}  
    80d1769a-7

从第几个字符开始取多少位
删除匹配字符串

    [root@node3 /server/scripts]# str=abcABC123ABCabc

    [root@node3 /server/scripts]# echo ${str}

    abcABC123ABCabc

    [root@node3 /server/scripts]# echo ${str#abc} ####从头开始删除最短匹配字符串

    ABC123ABCabc

    [root@node3 /server/scripts]# echo ${str%%abc} ####从尾开始删除最短匹配字符串

    abcABC123ABC

    [root@node3 /server/scripts]# echo ${str/abc/ABC/} ####把第一个匹配的字符替换

    ABC/ABC123ABCabc

    [root@node3 /server/scripts]# echo ${str//abc/ABC/} ####把所有匹配的字符替换

    ABC/ABC123ABCABC/


防止变量为空时,执行危险命令
当变量值不存在时,执行命令中含有该变量找不到,则会执行当前目录

    [root@node3 /server/scripts]# echo ${qwe-/tmp} ####–代表借用但是还是i没有该变量

    /tmp

    [root@node3 /server/scripts]# echo ${qwe}

    [root@node3 /server/scripts]# echo ${qwe=/tmp} = 代表创建了该变量

    /tmp

    [root@node3 /server/scripts]# echo ${qwe}

    /tmp



整数运算
双括号计算(只能计算整数与[]中括号一样的效果)

计算加减乘除

    [root@node3 /server/scripts]# echo $((1+2-654*642/6245%625+6452))

    6388

    [root@node3 /server/scripts]# a=$((1+2-654*642/6245%625+6452))

    [root@node3 /server/scripts]# echo $a

    6388

    [root@node3 /server/scripts]# ((b=1+2-654*642/6245%625+6452))

    [root@node3 /server/scripts]# echo $b

    6388

自加自减1

    [root@node3 /server/scripts]# a=1

    [root@node3 /server/scripts]# echo $((a++))

    1

    [root@node3 /server/scripts]# echo $a

    2

    [root@node3 /server/scripts]# echo $((++a))

    3

    [root@node3 /server/scripts]# echo $a

    3

判断大小

    [root@node3 /server/scripts]# echo $((3>2))

    1

    [root@node3 /server/scripts]# echo $((3>5))

    0

实现加减乘除的计算器(使用bc计算)

    [root@node3 /server/scripts]# cat jisuan.sh bc计算可以计算小数

    #!/bin/bash

    read -p “请输入你所需要计算的(例如:3+2*6-5/8.542+8.6846%3.1):: ” jisuan

    echo “scale=5;$jisuan” |bc


小数点显示5位

    [root@node3 /server/scripts]# sh jisuan.sh

    [root@node3 /server/scripts]# sh jisuan.sh

请输入你所需要计算的(例如:3+2*6-5/8.542+8.6846%3.1): 325+234.265/3245*6.62 325.47789

let计算方法
    [root@lb03 scripts]# i=1

    [root@lb03 scripts]# i=i+1

    [root@lb03 scripts]# echo $i

i+1

    [root@lb03 scripts]# i=1

    [root@lb03 scripts]# let i=i+1

    [root@lb03 scripts]# echo $i

    2

expr计算方法

    [root@node3 /server/scripts]# expr 1 + 1

    2

    [root@node3 /server/scripts]# expr 1 * 1 *有特殊含义,所以语法错误

    expr: syntax error

    [root@node3 /server/scripts]# expr 1 \* 1 需要\转义字符

    1

    [root@node3 /server/scripts]# expr 1 / 1

    1

    [root@node3 /server/scripts]# expr 1 – 1

    0

expr 计算后的返回值为2，则输入的参数存在非整数， 0或1 则为整数(0或1都表示计算正确,但计算结果为0时,echo$? 显示结果为1)

    [root@lb03 scripts]# expr 1 + 1

    2

    [root@lb03 scripts]# echo $?

    0

    [root@lb03 scripts]# expr 1 + a

    expr: 非整数参数

    [root@lb03 scripts]# echo $?

    2

    [root@lb03 scripts]# expr 1 + -1

    0

    [root@lb03 scripts]# echo $?

    1

    [root@lb03 scripts]# expr 2 – 2

    0

    [root@lb03 scripts]# echo $?

    1

    [root@lb03 scripts]# expr a + a

    expr: 非整数参数

    [root@lb03 scripts]# echo $?

    2