---
title: "防止手残rm"
date: 2019-09-28T16:59:57+08:00
tags: 
- 运维
categories:
- 运维
archives:
- 运维
---
Linux 下 rm 命令是表示删除一个文件，而Linux是没有回收站机制，所以文件一旦删除的话，就彻底从磁盘上删除了。而很多人喜欢加上 -f 选项，是代表强制的意思，更暴力的是删除文件夹的时候使用 rm -rf 命令，这样一来，文件夹本身，以及文件夹下的子子孙孙，都一了百了了。
<!--more-->

由于没有回收站机制，很多人吃过这个亏，良许也是，曾经辛苦写的几个月的代码，一个 rm 命令全部化为乌有，搞得每次执行 rm 命令的时候，手都是颤抖的……

既然Linux没有回收站，那我们能否自己实现一个？答案当然是肯定的。下面，我们就自己动手做一个回收站，给自己一个后悔的机会。

既然罪魁祸首是 rm 命令，那我们就对这个命令进行改造。在Linux下对命令进行重定义是使用 alias 命令，修改的是 .bashrc 文件，即：

vim ~/.bashrc
在文件尾部，我们添加以下几句代码：

mkdir -p ~/.trash

alias rm=trash

alias r=trash

alias rl='ls ~/.trash/'

alias ur=undelfile

undelfile()

{

      mv -i ~/.trash/$@ ./
}

trash()

{

     mv -i $@ ~/.trash/
	 
}

cleartrash()

{

   read -p "clear sure?[n]" confirm
   [ $confirm == 'y' ] || [ $confirm == 'Y' ] && /bin/rm -rf ~/.trash
		
}

在这里，我们是在家目录下建立一个 .trash 的隐藏文件夹，作为回收站。然后，我们对 rm 命令进行重定义。当我们执行 rm 或者 r 的时候，将执行 trash 函数。而在 trash 函数里，只做一件事：

mv -i $@ ~/.trash/

就是将 rm 之后所有的文件移动到 .trash 目录下（即模拟丢进回收站）。-i 选项表示如果 .trash 目录有同名文件的话，将提示是否覆盖。

我们将 rl 定义为 ls ~/.trash/ ，也就是说，我们可以通过 rl 来查看 .trash 目录下的文件，即被「删除」的文件。

如果要还原文件，可以执行 ur ，而 ur 将执行 undelfile 函数。在 undelfile 里，又将 ur 之后的文件从 .trash 目录移回到原目录，从而实现文件删除还原。

当过了一段时间后，回收站里文件太多了，我们可以使用 cleartrash 命令清空回收站。它将执行同名函数，调用 /bin/rm 命令将 .trash 目录清空。

.bashrc 文件修改完毕之后，我们要让它生效：

source ~/.bashrc

我们来实际体会一下：

删除文件

alvin@alvin-pc:~/test$ touch file1 file2 file3

alvin@alvin-pc:~/test$ ls

file1  file2  file3

alvin@alvin-pc:~/test$ rm file1 file2 

alvin@alvin-pc:~/test$ r 

查看回收站文件

alvin@alvin-pc:~/test$ rl

file1  file2  file3

还原被删除的文件

alvin@alvin-pc:~/test$ rl

file1  file2  file3

alvin@alvin-pc:~/test$ ur file1

alvin@alvin-pc:~/test$ ur file2

alvin@alvin-pc:~/test$ ur file3

alvin@alvin-pc:~/test$ ls

file1  file2  file3

alvin@alvin-pc:~/test$ rl

alvin@alvin-pc:~/test$ 

清空回收站

alvin@alvin-pc:~/test$ rm file1 file2 file3

alvin@alvin-pc:~/test$ rl

file1  file2  file3

alvin@alvin-pc:~/test$ cleartrash

clear sure?[n]y

alvin@alvin-pc:~/test$ rl

alvin@alvin-pc:~/test$

通过以上这些步骤，我们虽然可以实现一个回收站的功能，但实际的工作中，我们还是要养成定时备份的习惯，这样即使有误操作，我们也可以将损失降到最低。