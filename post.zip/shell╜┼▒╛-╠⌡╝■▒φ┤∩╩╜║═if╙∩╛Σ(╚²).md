---
title: "shell脚本 条件表达式和if语句(三)"
date: 2019-09-29T17:16:02+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
条件表达式和if语句
<!--more-->
文件判断操作符

判断文件表达式 -f

    [root@node3 /server/scripts]# [ -f /etc/hosts ] && echo “ok” || echo “no”

ok 判断文件的表达式
正确显示ok 不正确显示no

    [root@node3 /server/scripts]# [ -f /etc/host ] && echo “ok” || echo “no”

    no

判断目录表达式 -d

    [root@node3 /server/scripts]# [ -d /etc/host ] && echo “ok” || echo “no”

no 判断目录的表达式
正确显示ok 不正确显示no

    [root@node3 /server/scripts]# [ -d /etc/ ] && echo “ok” || echo “no”

    ok

判断文件存在与否且不为0,则表达式成立 -s

    [root@node3 /server/scripts]# touch 3306.txt

    [root@node3 /server/scripts]# [ -s /server/scripts/3306.txt ] && echo “ok” || echo “no”

    no

    [root@node3 /server/scripts]# echo 6606 >3306.txt

    [root@node3 /server/scripts]# [ -s /server/scripts/3306.txt ] && echo “ok” || echo “no”

    ok

字符串判断操作符

判断字符串长度是否为0 -z

    [root@node3 /server/scripts]# [ -z “$z” ] && echo “ok” || echo “no”

ok 判断$z的字符串长度
若为0则显示ok 若不为0 则显示no

    [root@node3 /server/scripts]# echo $z

    [root@node3 /server/scripts]# z=123

    [root@node3 /server/scripts]# [ -z “$z” ] && echo “ok” || echo “no”

    no

 ####将z的变量值设置为一个空格, 空格也算一个字符串

    [root@node3 /server/scripts]# z=” ”

    [root@node3 /server/scripts]# [ -z “$z” ] && echo “ok” || echo “no”

    no

若字符串长度不为0 -n

    [root@node3 /server/scripts]# z=” ”

    [root@node3 /server/scripts]# [ -n “$z” ] && echo “ok” || echo “no”

ok 若变量z的字符串长度不是0 则显示ok 反之则显示no

    [root@node3 /server/scripts]# z=

    [root@node3 /server/scripts]# [ -n “$z” ] && echo “ok” || echo “no”

    no

    [root@node3 /server/scripts]# z=1

    [root@node3 /server/scripts]# [ -n “$z” ] && echo “ok” || echo “no”

    ok

判断两个字符是否相同 == 或者 = 不等于用!=  字符串比较必须加双引号,且与对比符号间必须有空格

    [root@node3 /server/scripts]# z=1

    [root@node3 /server/scripts]# echo $z

    1

    [root@node3 /server/scripts]# y=$z

    [root@node3 /server/scripts]# [ “$y” = “$z” ] && echo “ok” || echo “no”

    ok   ####y与变量z相同时显示ok 不同显示no

    [root@node3 /server/scripts]# echo $y

    1

    [root@node3 /server/scripts]# y=z

    [root@node3 /server/scripts]# [ “$y” = “$z” ] && echo “ok” || echo “no”

    no

    [root@node3 /server/scripts]# y=a

    [root@node3 /server/scripts]# [ “$y” != “$z” ] && echo “ok” || echo “no”

    ok    ####y与变量z不同时显示ok 相同显示no

整数判断操作符

    [root@node3 /server/scripts]# [ 1 -eq 1 ] && echo “ok” || echo “no”

    ok    等于

    [root@node3 /server/scripts]# [ 1 -ne 2 ] && echo “ok” || echo “no”

    ok    不等于

    [root@node3 /server/scripts]# [ 2 -gt 1 ] && echo “ok” || echo “no”

    ok    大于

    [root@node3 /server/scripts]# [ 2 -ge 1 ] && echo “ok” || echo “no”

    ok    大于等于(或的关系)

    [root@node3 /server/scripts]# [ 2 -ge 2 ] && echo “ok” || echo “no”

    ok    大于等于(或的关系)

    [root@node3 /server/scripts]# [ 1 -lt 2 ] && echo “ok” || echo “no”

    ok    小于

    [root@node3 /server/scripts]# [ 1 -le 2 ] && echo “ok” || echo “no”

    ok    小于等于

    [root@node3 /server/scripts]# [ 1 -le 1 ] && echo “ok” || echo “no”

    ok    小于等于


逻辑操作符	-a	-o	!
说明	“和” 的关系,都要满足	“或” 的关系	非:排除改这个参数

练习题

使用if语句定义变量对比两个整数 的大小

    [root@node3 /server/scripts]# vim Dv.sh

    #!/bin/bash

        numa=1    可以修改数字

        numb=2

        expr 1 + $numa > /dev/null

        if

    [ $? -eq 2 ];then

        echo “您输入的不是整数”

        exit 2

    fi

        expr 1 + $numb > /dev/null

    if

    [ $? -eq 2 ];then

        echo “您输入的不是整数”

        exit 2

    fi

    if

    [ $numa -eq $numb ];then

        echo “$numa=$numb”

        elif

    [ $numa -gt $numb ];then

        echo “$numa>$numb”

    else

    echo “$numa<$numb”

    [root@node3 /server/scripts]# sh Dv.sh

        1<2

传参对比两个整数的大小

    [root@node3 /server/scripts]# vim Tp.sh

    #!/bin/bash

    if

    [ $# -ne 2 ];then

    echo “请输入两个整数”

    exit

    fi

    numa=$1

    numb=$2

    expr 1 + $numa >/dev/null

    if

    [ $? -eq 2 ];then

    echo “您输入的不是整数”

    exit 2

    fi

    expr 1 + $numb >/dev/null

    if

    [ $? -eq 2 ];then

    echo “您输入的不是整数”

    exit 2

    fi

    if

    [ $numa -eq $numb ];then

    echo “$numa=$numb”

    elif

    [ $numa -gt $numb ];then

    echo “$numa>$numb”

    else

    echo “$numa<$numb”

    fi

    [root@node3 /server/scripts]# sh Tp.sh 3 5

    3<5

    [root@node3 /server/scripts]# sh Tp.sh 3 3

    3=3

    [root@node3 /server/scripts]# sh Tp.sh 3 2

    3>2

    [root@node3 /server/scripts]# sh Tp.sh 3 2.0

    expr: non-integer argument

    您输入的不是整数

用交互方式对比两个整数大小

    [root@node3 /server/scripts]# vim read.sh

    #!/bin/bash

    read -p “第一个数字: ” numa

    expr 1 + $numa > /dev/null

    if

    [ $? -eq 2 ];then

    echo “不是整数”

    exit

    fi

    read -p “第二个数字: ” numb

    expr 1 + $numb > /dev/null

    if

    [ $? -eq 2 ];then

    echo “不是整数”

    exit

    fi

    if

    [ $numa -eq $numb ];then

    echo “$numa=$numb”

    elif

    [ $numa -gt $numb ];then

    echo “$numa>$numb”

    else

    echo “$numa<$numb”

    fi

    [root@node3 /server/scripts]# sh read.sh

    第一个数字: 6

    第二个数字: 5

    6>5

使用if判断语句脚本监控当内存低于100M时发送邮件报警

    [root@node3 /server/scripts]# vim memory_alarm.sh

    #!/bin/bash

    centos_x=$(uname -r |awk -F ‘[.]’ ‘{print $4}’) #查看系统版本

    available_el7=$(free -m |awk -F ‘[ ]+’ ‘NR==2{print $NF}’) #查看centos7 的剩余内存

    available_el6=$(free -m |awk -F ‘[ ]+’ ‘NR==3{print $NF}’) #查看centos6 的剩余内存

    if

    [ $centos_x = el7 -a $available_el7 -lt 1024 ];then

    echo “内存不足” |mail -s “tile” 13522339471@163.com

    elif

    [ $centos_x = el6 -a $available_el6 -lt 1024 ];then

    echo “内存不足” |mail -s “tile” 13522339471@163.com

    else

    echo “The system you use is not centos6 or centos7,Please replace your system.”

    fi