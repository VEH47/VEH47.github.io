---
title: "Shell脚本 While循环语句企业面试题(六)"
date: 2019-09-29T17:18:35+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
While循环语句企业面试题
<!--more-->
while 循环语句
死循环查看负载

    [root@node3 /server/scripts]# vim deadloop.sh

    #!/bin/bash

    while true

    do

    uptime

    sleep 1

    done

    发短信每条1.5角,充值10元
    [root@node3 /server/scripts]# vim short_letter.sh

    #!/bin/bash

    ##############################################################

    #File Name: shouji.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-31 09:24:18

    #Description:

    ##############################################################

    i=100

    while [ $i -ge 15 ]

    do

    read -p “您需要什么业务(短信|充值|退出|,请输入DX|CZ|EXIT):” a

    case $a in

    DX)

    echo “你已经发送一条短信”

    echo “您的余额:$((i=i-15))”

    if [ $i -lt 15 ];then

    echo “余额不足,请及时充值”

    fi

    ;;

    CZ)

    read -p “请输入你要充值的金额:” b

    echo “您的余额:$((i=$i+$b))”

    if [ $b -lt 1000 ];then

    echo “最少充值100分”

    fi

    ;;

    EXIT)

    echo “您已退出业务” && exit

    ;;

    *)

    echo “请正确选择业务(DX|CZ|EXIT)”

    esac

    done

解决DOS攻击
请根据日志或web连接数监控当某个ip端渐渐内pv达到100,调用放或轻命令封掉

    [root@node3 /server/scripts]# vim close_ip.sh

    #!/bin/bash

    message=/root/access.log

    while true

    ipadd=$(awk ‘{print $1}’ $message|sort|uniq -c|sort -rn| awk ‘{if($1>500)print $2}’)

    do

    for rule in $ipadd

    do

    num=$(iptables -nL|grep -c $rule)

    if [ $num -eq 0 ];then

    iptables -I INPUT -s $rule -j DROP

    echo “$rule 已封禁”

    fi

    done

    sleep 10

    done

循环小技巧
显示文件的每一行并标出第几行

    [root@node3 /server/scripts]# vim print.sh

    #!/bin/bash

    File=/etc/hosts

    num=1

    while read i

    do

    echo “第${num}行$i”

    ((num++))

    done<$File

显示每一行的每个单词

    [root@node3 /server/scripts]# vim print.sh

    #!/bin/bash

    ##############################################################

    #File Name: print.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-31 11:51:51

    #Description:

    ##############################################################

    File=/etc/hosts

    numa=1

    while read i

    do

    echo “第${numa}行$i”

    ((numa++))

    numb=1

    for x in $i

    do

    echo “第$numb个单词:$x”

    ((numb++))

    done

    done<$File

显示每一行每一个单词的每一个字母

    [root@node3 /server/scripts]# vim print.sh

    #!/bin/bash

    ##############################################################

    #File Name: print.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-31 11:51:51

    #Description:

    ##############################################################

    File=/etc/hosts

    numa=1

    while read i

    do

    echo “第${numa}行$i”

    ((numa++))

    numb=1

    for x in $i

    do

    echo “第$numb个单词:$x”

    ((numb++))

    echo $x|grep -o .

    done

    done<$File

break 立刻跳出循环（后面的循环不再执行），但是不跳出（退出）脚本

    [root@node3 /server/scripts]# vim break.sh

    #!/bin/bash

    ##############################################################

    #File Name: break.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-31 16:42:33

    #Description:

    ##############################################################

    for i in {1..5}

    do

    if [ $i -eq 3 ];then

    break;

    fi

    echo $i

    done

    echo ok

    [root@node3 /server/scripts]# sh break.sh

    1

    2

    ok

continue 跳出当前循环，继续执行下面循环（后面的循环依然执行）

    [root@node3 /server/scripts]# vim break.sh

    #!/bin/bash

    for i in {1..5}

    do

    if [ $i -eq 3 ];then

    continue;

    fi

    echo $i

    done

    echo ok

    [root@node3 /server/scripts]# sh break.sh

    1

    2

    4

    5

    ok

exit的作用是立刻退出脚本，后面所有循环和所有没有执行的代码就当没看见

    [root@node3 /server/scripts]# vim break.sh

    #!/bin/bash

    ##############################################################

    #File Name: break.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-31 16:42:33

    #Description:

    ##############################################################

    for i in {1..5}

    do

    if [ $i -eq 3 ];then

    exit;

    fi

    echo $i

    done

    echo ok

    [root@node3 /server/scripts]# sh break.sh

    1

    2