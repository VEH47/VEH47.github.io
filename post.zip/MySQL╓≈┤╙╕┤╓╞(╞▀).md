---
title: "MySQL主从复制(七)"
date: 2019-09-29T18:05:59+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
MySQL主从复制
<!--more-->
复制的实现前提

1、至少两台机器，1主1从

2、主服务器需要开启二进制日志

3、主从节点之间需要有唯一的标识，server_id

4、二进制日志是从库请求主库才会得到的，主库不会主动发给从库

5、节点之间网络要畅通，防火墙需要关闭

6、主库必须有一个专门用作复制的用户（replication slave）

7、从库请求二进制日志需要有一个起点，在第一次构建主从的时候，需要人为设置起点。

注：

情况一：两个库都是新搭建的，直接指定第一个二进制日志开始位置即可

情况二：主库已经运行了很长时间了，从库是新加的。如果你能保证主库所有二进制日志都在的话，也可以从第一个的开头位置开始

但是需要很长时间。我们也可借助备份主库当前的数据，然后告诉从库从备份完成时刻之后的二进制日志位置开始请求即可。

8、第一次搭建的时候，需要通过change mater to 语句告诉从库他需要的：用户名+密码+主库地址+端口号+二进制日志文件名+二进制日志起始请求位置

9、需要从库执行 start slave 开启主从复制需要的一堆线程

主从复制的原理

从库关键文件：

1、master.info

用户名 密码 主机名 端口号

上次请求主库到哪一个二进制文件和position号

2、relay-log

记录从库请求过来的二进制日志的事件，已经执行过的relay log会被自动清理

3、relay-log.info

记录已经执行过的relay log的事件信息

从中关键的线程：

start slave命令执行完成之后，从库会开启IO线程和SQL线程来完成复制过程

1、IO线程：会拿着master.info 中二进制文件信息（文件名+position），去问主库有没有更新的二进制日志事件。

主库会接收请求，通过dump线程和从库IO线程进行交互，如果有更新的binlog就发送给从库IO线程。IO线程接收binlog之后，

会将binlog 事件写入到relay-log中存储。同时IO线程会将新请求过来的binlog信息写入到master.info中。

2、SQL线程：SQL线程会检查relay-log.info，会去relay-log中找没执行过的relay-log事件继续执行。执行完成后，再次更新relay-log.info





准备两个MySQL实例（单独主机或多实例） 3306（master）和 3307（slave）多实例

配置文件修改

        3306 ：

        log-bin=/data/3306/mysql-bin

        server-id=3306

        3307:

        server-id=3307

启动多实例

    mysqld_safe –defaults-file=/data/3306/my.cnf &

    mysqld_safe –defaults-file=/data/3307/my.cnf &

    mysqld_safe –defaults-file=/data/3308/my.cnf &

    netstat -lnp|grep 330

主库创建复制用户

    mysql -S /data/3306/mysql.sock

    grant replication slave on *.* to repl@’10.0.0.5%’ identified by ‘123’;

备份主库并记录position

mysqldump -A –master-data=2 –single-transaction -S /data/3306/mysql.sock >/backup/full.sql 全备文件

从库恢复备份

    mysql -S /data/3307/mysql.sock

    set sql_log_bin=0;

    source /backup/full.sql;

从库change master to并开启主从复制

    CHANGE MASTER TO

    MASTER_HOST=’10.0.0.52′, 主库ip

    MASTER_USER=’repl’, 主库创建的复制用户

    MASTER_PASSWORD=’123′, 复制用户的密码

    MASTER_PORT=3306, 主库

    MASTER_LOG_FILE=’mysql-bin.000004′,

    MASTER_LOG_POS=326;

全备文件的第22行(打开全备文件就能找到以下信息,输入到从库
的change master to中)

— CHANGE MASTER TO MASTER_LOG_FILE=’mysql-bin.000004′, MASTER_LOG_POS=326;

从库启动并查询复制状态：
start slave;

show slave status\G;

主从复制故障处理

    Slave_IO_Running: Connecting

    Slave_SQL_Running: Yes

    Last_IO_Errno: 1045

    Last_IO_Error: error connecting to master ‘repl@10.0.0.52:3306’ – retry-time: 60 retries: 1

    Last_SQL_Errno: 0

    Last_SQL_Error:

IO线程问题情况：
1、连接不上：网络、用户、密码、端口号、解析

2、其他：主库二进制日志不连续或不存在

3、relay-log文件权限不足

等等。

以上问题解决：

主库参数文件中加入：

skip_name_resolve

SQL线程出现问题情况：
主要原因是从库做了写入操作。

临时解决方案:

stop slave;

set global sql_slave_skip_counter= 1

start slave;

/etc/my.cnf

slave-skip-errors = 1032,1062,1007

最有效最稳妥的解决方案：重新搭建主从。(看实际情况而定)

如何避免？
设置从库只读

read_only=1

半同步复制
为了解决主从一致性问题

1主1从情况，从库必须确认将请求过来的二进制日志落地，才返回ACK给主库

1主多从的情况，只要其中一台机器，二进制日志落地，就返回ACK给主库

配置过程 加载插件
主:

install pluginrpl_semi_sync_master soname ‘semisync_master.so’;

从:

install pluginrpl_semi_sync_slave soname ‘semisync_slave.so’;

查看是否加载成功:

show plugins;

启动:
主:

set global rpl_semi_sync_master_enabled = 1;

从:

set global rpl_semi_sync_slave_enabled = 1;

重启从库上的IO线程

STOP SLAVE IO_THREAD;

START SLAVE IO_THREAD;

查看是否在运行
主:

show status like ‘Rpl_semi_sync_master_status’;

从:

show status like ‘Rpl_semi_sync_slave_status’;

测试:
查看延迟时间:

show variables like ‘%rpl_semi_sync%’;

延迟复制
SQL配置延时，防止逻辑损坏

root@localhost:mysql>stop slave;

Query OK, 0 rows affected (0.21 sec)

root@localhost:mysql>CHANGE MASTER TO MASTER_DELAY = 30;

Query OK, 0 rows affected (0.17 sec)

root@localhost:mysql>start slave;

Query OK, 0 rows affected (0.27 sec)