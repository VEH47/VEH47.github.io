---
title: "Shell脚本 For循环语句企业面试题(五)"
date: 2019-09-29T17:18:04+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
For循环语句企业面试题
<!--more-->
批量生成随机字符
随机生成10个文件

要求:使用for循环在/oldboy目录下创建10个html文件,每个文件要包含10个随机字母,和固定字符oldboy.例如kfdkgjbxdk_oldboy.html

    [root@node3 /server/scripts]# cat loop.sh

    #!/bin/bash

    dir=/oldboy/

    [ -d $dir ] || mkdir -p /oldboy && cd /oldboy

    for i in {1..10}

    do

    random=$(uuidgen |tr “[0-9-]” “[a-z]” |cut -c 1-10)

    touch /oldboy/${random}_oldboy.html

    done

把上述所创建地文件,随机字符不变,oldboy修改为oldgir html改为大写

    [root@node3 /server/scripts]# cat modify.sh

    #!/bin/bash

    cd /oldboy

    for i in \`ls *\`

    do

    random=$(echo $i |cut -c 1-10)

    mv $i ${random}_girl.HTML

    done

批量创建10个系统帐号oldboy01-oldboy10并设置密码（密码为随机数，要求字符和数字等混合）

    [root@node3 /server/scripts]# vim useradd.sh

    #!/bin/bash

    ##############################################################

    #File Name: useradd.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-30 15:31:48

    #Description:

    ##############################################################

    source /etc/init.d/functions

    for i in oldboy{01..10}

    do

    useradd $i &>/dev/null

    if

    [ $? -eq 0 ];then

    action “$i” /bin/true

    passwd=`uuidgen`

    echo $passwd |passwd –stdin $i &>/dev/null

    echo “user: $i password: $passwd” >>/tmp/123.txt

    else

    action “$i” /bin/false

    fi

    done

写一个Shell脚本，判断10.0.0.0/24网络里，当前在线的IP有哪些？

    [root@node3 /server/scripts]# vim ping.sh

    #!/bin/bash

    source /etc/init.d/functions

    for i in {1..254}

    do

    {

    ping -c 1 -W 1 10.0.0.$i &>/dev/null

    if [ $? -eq 0 ];then

    action “$i” /bin/true

    fi

    } &

    done

利用bash for循环打印下面这句话中字母数不大于6的单词。 I am oldboy teacher welcome to oldboy trainingclass

    [root@node3 /server/scripts]# vim duibi.sh

    #!/bin/bash

    for i in I am oldboy teacher welcome to oldboy trainingclass

    do

    if

    [ “${#i}” -le 6 ];then

    echo $i

    fi

    done

已知下面的字符串是通过RANDOM随机数变量md5sum后，再截取一部分连续字符串的结果，请破解这些字符串对应的使用md5sum处理前的RANDOM对应的数字？

21029299

00205d1c

a3da1677

1f6d12dd

890684b

    [root@node3 /server/scripts]# vim passwd.sh

    #!/bin/bash

    for i in {1..32767}

    do

    echo “$i : $($i |md5sum)” >>/tmp/456.txt

    done

    egrep “21029299|00205d1c|a3da1677|1f6d12dd|890684b” /tmp/456.txt