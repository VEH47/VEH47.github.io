---
title: "Shell脚本 If语句企业练习题及case语句(四)"
date: 2019-09-29T17:17:34+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
练习nginx启动脚本
<!--more-->

    [root@node3 /server/scripts]# cat NGINX_process.sh

    #!/bin/bash

    source /etc/init.d/functions

    CMD=$1

    start=/application/nginx/sbin/nginx

    if [ “$#” -ne “1” ];then

    echo “The parameter is not one, Please enter start|stop|restart|reload”

    fi

    number_nginx=$(ps -ef |grep nginx|wc -l)

    if

    [ “$CMD” = “start” ];then

    “$start” && action “start nginx” /bin/true

    elif

    [ “$CMD” = “stop” ];then

    pkill nginx && action “stop nginx” /bin/true

    elif

    [ “$number_nginx” -ge 3 -a “$CMD” = “restart” ];then

    pkill nginx && usleep 100 && “$start” && \

    action “stop nginx” /bin/true && action “start nginx” /bin/true

    elif

    [ “$number_nginx” -lt 3 -a “$CMD” = “restart” ];then

    “$start” && echo “Service is closed” && \

    action “restart nginx” /bin/true

    elif

    [ “$number_nginx” -ge 3 -a “$CMD” = “reload” ];then

    “$start” -s reload && \

    action “reload nginx” /bin/true

    else

    echo “The parameter is not one, Please enter start|stop|restart|reload”

    fi

    web 服务监测脚本
    [root@node3 /server/scripts]# cat web_monitor.sh

    #!/bin/bash

    #nginx port

    port_nginx=$(netstat -lntup |grep nginx |awk -F ‘[: ]+’ ‘{print $5}’)

    source /etc/init.d/functions

    #Check whether the web page is normal by monitoring the nginx port 80

    if

    [ “$port_nginx” = “80” ];then

    echo “nginx is running”

    else

    echo “nginx is not running ” && \

    /application/nginx/sbin/nginx && action “start nginx” /bin/true

    fi

监控Memcached缓存服务是否正常

    [root@cache01 /server/scripts]# cat MEMCACHE.sh

    #!/bin/bash

    ip=10.0.0.21

    pro=11211

    str=$(printf “set key008 0 0 3\r\nhkx\r\n”|nc $ip $pro)

    get_str=$(printf “get key008\r\n “|nc $ip $pro |awk NR==2 |tr -d ‘\r’)

    if

    [ “hkx” = “$get_str” ];then

    echo “memcache is running”

    else

    echo “memcache is not running”

    fi

显示菜单,并改变字符颜色(使用case语句)
查看颜色

    [root@oldboy ~]# man console_codes  #查看具体上面

    echo -e “\033[30m 黑色字oldboy trainning \033[0m”

    echo -e “\033[31m 红色字oldboy trainning \033[0m”

    echo -e “\033[32m 绿色字oldboy trainning \033[0m”

    echo -e “\033[33m 黄色字oldboy trainning \033[0m”

    echo -e “\033[34m 蓝色字oldboy trainning \033[0m”

    echo -e “\033[35m 紫色字oldboy trainning \033[0m”

    echo -e “\033[36m 天蓝字oldboy trainning \033[0m”

    echo -e “\033[37m 白色字oldboy trainning \033[0m”

    echo -e “\033[40;37m 黑底白字 welcome to old1boy\033[0m”

    echo -e “\033[41;37m 红底白字 welcome to old2boy\033[0m”

    echo -e “\033[42;37m 绿底白字 welcome to old3boy\033[0m”

    echo -e “\033[43;37m 黄底白字 welcome to old4boy\033[0m”

    echo -e “\033[44;37m 蓝底白字 welcome to old5boy\033[0m”

    echo -e “\033[45;37m 紫底白字 welcome to old6boy\033[0m”

    echo -e “\033[46;37m 天蓝白字 welcome to old7boy\033[0m”

    echo -e “\033[47;30m 白底黑字 welcome to old8boy\033[0m”

    \033[0m 关闭所有属性

    \033[1m 设置高亮度

    \033[4m 下划线

    \033[5m 闪烁

    \033[7m 反显

    \033[8m 消隐

    \033[30m — \033[37m 设置前景色

    \033[40m — \033[47m 设置背景色

    \033[nA 光标上移 n 行

    \033[nB 光标下移 n 行

    \033[nC 光标右移 n 行

    \033[nD 光标左移 n 行

    \033[y;xH 设置光标位置

    \033[2J 清屏

    \033[K 清除从光标到行尾的内容

    \033[s 保存光标位置

    \033[u 恢复光标位置

    \033[?25l 隐藏光标

    \033[?25h 显示光标

利用菜单显示字符颜色

    [root@node3 /server/scripts]# cat fruit_menu.sh

    #!/bin/bash

    ##############################################################

    #File Name: menu.sh

    #Version: V1.0

    #Author: Eleven

    #Organization: 2415069806

    #Created Time : 2018-01-29 10:35:07

    #Description:

    ##############################################################

    <<EOF 菜单可以用这种方式

    cat <<EOF

    1.apple

    2.Banana

    3.Pear

    4.peach

    EOF

    echo ====================

    echo -e “\033[31m 1.apple \033[0m” 也可以用这种方式改变菜单颜色

    echo -e “\033[33m 2.Banana \033[0m”

    echo -e “\033[32m 3.Pear \033[0m”

    echo -e “\033[37m 4.peach \033[0m”

    echo ====================

    read -p “请输入数字1-4: ” a

    case $a in

    1)

    echo -e “\033[31m apple \033[0m”

    ;;

    2)

    echo -e “\033[33m Banana \033[0m”

    ;;

    3)

    echo -e “\033[32m Pear \033[0m”

    ;;

    4)

    echo -e “\033[37m peach \033[0m”

    ;;

    *)

    echo -e “\033[41;37m Input error \033[0m”

    esac

网络服务独立进程模式下Rsync的系统启动脚本

    [root@node3 /server/scripts]# cat RSYNC.sh

    #!/bin/bash

    port=$(netstat -lntup |grep rsync|awk -F ‘[: ]+’ ‘NR==1 {print $5}’)

    source /etc/init.d/functions

    if

    [ “$#” -ne “1” ];then

    echo “Parameter input error, please enter start|stop|restart|status” && \

    exit

    fi

    case $1 in

    start)

    if [ “$port” = “873” ];then

    echo “rsync is running”

    else

    systemctl start rsyncd && action “start rsync” /bin/true

    fi

    ;;

    stop)

    if [ “$port” = “873” ];then

    pkill rsync && usleep 100 && \

    action “stop rsync” /bin/true

    else

    echo “rsync is not running”

    fi

    ;;

    restart)

    if [ “$port” = “873” ];then

    pkill rsync && sleep 1 && action “stop rsync” /bin/true && \

    systemctl start rsyncd && action “start rsync” /bin/true

    else

    echo “rsync is not running” && systemctl start rsyncd && \

    action “start rsync” /bin/true

    fi

    ;;

    status)

    if [ “$port” = “873” ];then

    echo “rsync is running”

    else

    echo “rsync is not running”

    fi

    ;;

    esac

    打印选择菜单，按照选择一键安装不同的Web服务
    [root@node3 /server/scripts]# cat install_lnmp.sh

    #!/bin/bash

    cat <<EOF

    1.[install lamp]

    2.[install lnmp]

    3.[exit]

    EOF

    read -p “请输入你所需要的菜单数字: ” num

    case $num in

    1)

    if

    [ -f /server/scripts/lamp.sh ];then

    echo ‘start installing lamp’ && sh lamp.sh

    else

    echo ‘lamp.sh Non-existent’

    fi

    ;;

    2)

    if

    [ -f /server/scripts/lnmp.sh ];then

    echo ‘start installing lnmp’ && sh lnmp.sh

    else

    echo ‘lnmp.sh Non-existent’

    fi

    ;;

    3)

    exit

    ;;

    *)

    echo ‘Input error’

    esac