---
title: "Mysql主从复制中的Failover GTID MHA高可用技术(八)"
date: 2019-09-29T18:06:26+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
Mysql主从复制中的Failover GTID MHA高可用技术
<!--more-->
主从复制中的Failover过程

0、实时监控所有节点的状态

1、选择一个新主，选择标准是和主库越接近越好 , 通过对比SLAVE 的master.info

2、APP应用程序需要连接到新的主库继续工作，通过切换VIP实现，让应用程序感知不到。

3、数据补偿

SSH可以通的话，通过Master.info的信息，去主库 保存缺失部分的binlog即可

SSH不通的情况：

（1）S2到S1的数据补偿

通过对比两个节点的relay的position号，计算差异, 拿到S2节点恢复即可。但是这里要有一个前提：

1、两个节点的relay是对等的（file和postion）

2、relaylog设置为不自动purge

但是这种classic传统的主从复制的方式，要以上relay的对等性，所有一点都是在同一时间加入集群

GTID复制

MySQL GTID简介

GTID(Global Transaction ID)是对于一个已提交事务的编号，并且是全局唯一的编号。

它的官方定义如下：

GTID = source_id ：transaction_id

UUID:TX_ID

UUID 存放在数据目录下的auto.cnf, 数据库初始化完成之后都会生成一串唯一号码。

在构建GTID模式复制环境时，需要保证节点之间，除了server_id不同还要保证uuid不同

GTID例子：

7E11FA47-31CA-19E1-9E56-C43AA21293967:29

7E11FA47-31CA-19E1-9E56-C43AA21293967:1-29

7E11FA47-31CA-19E1-9E56-C43AA21293967:10-29

GTID中的TX_ID都是连续的

GTID开启方式：

gtid-mode=on ——>GTID模式开关

enforce-gtid-consistency=true ——>强制GTID的一致性

log-slave-updates=1                 ——>5.6版本，强制更新binlog

GTID优势

1、Failover时数据补偿很方便

2、构建主从时也更方便了

GTID复制原理的新特性

change master to语句

Classic复制模式：

从库会一致拿着master从库会一致拿着master.info中的最后一个从主库请求过来的position号问主库，有没有比这个更新的事件， 如果有就拿过来。请求过来后，保存到relaylog中，并且更新master.info binlog信息。

GTID复制模式：

从库读取relaylog最后一个事件信息，获取到最后一个GTID号码，去主库中问，有没有比这个GTID还新的事务，有的话就拿过来。也存放到relaylog当中，也会更新master.info 新的binlog的信息。

第一次开启GTID主从的时候，我们是不需要人为告诉从库从哪个开始请求主库的binlog，会自动先去读relaylog，发现没有东西。那么他会直接去找主库要所有binlog中的事务，默认是从第一个事务开始请求的。

如果主库binlog中事务记录不全或者或者有断点，从库复制就会异常。这时，我们可以备份主库，让从库从备份结束后的那个GTID开始往后复制即可。

搭建GTID复制的两种场景

1、全新搭建的

change master to

master_host=’10.0.0.51′,

master_user=’repl’,

master_password=’123′,

master_auto_position=1;

2、如果运行很长时间主库，需要开启主从，我们建议

先备份恢复到从库，让从库从备份后的gtid开始请求。

change master to

master_host=’10.0.0.51′,

master_user=’repl’,

master_password=’123′,

master_auto_position=1;

GTID复制实践（1主2从）

设置配置参数

———–db01——–

    server-id=10

    port=3306

    log-bin=/data/mysql/mysql-bin

    binlog_format=row

    gtid-mode=on

    enforce-gtid-consistency=true

    log-slave-updates=1



———-db02——————-

    server-id=20

    port=3306

    log-bin=/data/mysql/mysql-bin

    binlog_format=row

    gtid-mode=on

    enforce-gtid-consistency=true

    log-slave-updates=1


————–db03—————-

    server-id=30

    port=3306

    log-bin=/data/mysql/mysql-bin

    binlog_format=row

    gtid-mode=on

    enforce-gtid-consistency=true

    log-slave-updates=1



初始化数据（三个节点都要做）

    /application/mysql/scripts/mysql_install_db –defaults-file=/etc/my.cnf –user=mysql –basedir=/application/mysql –datadir=/application/mysql/data

    /etc/init.d/mysqld start

主库（db01）创建复制用户

GRANT REPLICATION SLAVE ON *.* TO repl@’10.0.0.%’ IDENTIFIED BY ‘123’;

构建主从

    change master to

    master_host=’10.0.0.52′,

    master_user=’repl’,

    master_password=’123′,

    master_auto_position=1;

开启并查看主从状态

    start slave;

    show slave status;

故障处理：

    stop slave;

    set gtid_next=’ffcf237c-1cfb-11e8-9a86-000c2939ea23:4′;

    begin;commit;

    set gtid_next=’AUTOMATIC’;

    start slave;

mysql MHA高可用

基本功能

1、监控

2、选主

3、数据补偿

附加功能（外置脚本）：

4、VIP（自带的，有模板修改一下即可）

5、故障通知：邮件（自带的接口，没自带现成脚本，只有模板需要自己开发）、微信、短信

软件结构

Manager软件(管理)，监控、切换、外置脚本调用、状态检查，一般企业是放在单独机器上的，可以管理多套1主多从的复制结构的

Node软件：代理式的软件，需要安装在所有复制结构中的节点上的

工作原理（M、S1（数据较新的） 、S2）

当主库（M）宕机（服务宕了、主机宕了）时：

1、Manager会监控到主库宕机的事件

2、先选择一个较新的从库S1，作为新主

3、判断主库是否能连接

1）能ssh连上，从节点会立即保存主库的binlog缺失部分的事件，恢复到本节点，构建新的主从关系。

2）不能连上，S2和S1比较relay-log gtid，将S2缺失的部分事件补偿到S2上， 构建新的主从关系。Manager退出（将配置文件故障节点剔除）。

**4、调用预设vip切换脚本，将vip切换到新主上，继续提供服务。

**5、调用预设的 send_report脚本，发送警告邮件给管理员

**6、binlogserver保存所有主库的binlog。

7、Manager退出（将配置文件故障节点剔除）。



搭建MHA高可用集群
思路：

1、三台mysql独立节点实例，开启1主2从GTID复制结构

2、关闭各节点relay-log自动删除功能

3、各节点部署node工具包及依赖包

4、选择其中一个从节点进行部署manager工具包

5、各节点ssh秘钥互信配置

6、配置manager节点配置文件（注意在数据库中添加mha管理用户和密码）

7、做ssh互信检查和主从状态检查

8、开启MHA功能，启动Manager

工具介绍
Manager工具包主要包括以下几个工具：

masterha_check_ssh             检查MHA的SSH配置状况

masterha_check_repl         检查MySQL复制状况

masterha_manger                 启动MHA

masterha_check_status         检测当前MHA运行状态

masterha_master_monitor     检测master是否宕机

masterha_master_switch         控制故障转移（自动或者手动）

masterha_conf_host             添加或删除配置的server信息


Node工具包（这些工具通常由MHA Manager的脚本触发，无需人为操作）主要包括以下几个工具：

save_binary_logs             保存和复制master的二进制日志

apply_diff_relay_logs         识别差异的中继日志事件并将其差异的事件应用于其他的

slave filter_mysqlbinlog     去除不必要的ROLLBACK事件（MHA已不再使用这个工具）

purge_relay_logs             清除中继日志（不会阻塞SQL线程）

MHA部署

解压MHA软件

每个节点都需要解压

安装依赖包（每个节点）：

yum install -y perl-DBD-MySQL

安装node工具包（每个节点）：

rpm -ivh mha4mysql-node-0.56-0.el6.noarch.rpm

安装manager依赖包(需要作为manager的节点,一般都是某个从库)

wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-6.repo

yum install -y perl-Config-Tiny epel-release perl-Log-Dispatch perl-Parallel-ForkManager perl-Time-HiRes

安装manager软件(manager节点)

rpm -ivh mha4mysql-manager-0.56-0.el6.noarch.rpm

关闭relaylog自动删除（所有节点）和从库只读

set global relay_log_purge = 0;     临时（建议三个节点都做）

relay_log_purge = 0                 永久，在配置文件，建议在三个节点都做

set global read_only=1;         临时，为后续读写分离准备，不需要在配置文件生效（在所有从库）

主库（db01）中创建mha管理用户

grant all privileges on *.* to mha@’10.0.0.%’ identified by ‘mha’;

注：mha用户是manager监控和管理节点使用的用户。

配置软连接(所有节点)

ln -s /application/mysql/bin/mysqlbinlog /usr/bin/mysqlbinlog

ln -s /application/mysql/bin/mysql /usr/bin/mysql

重要！！！！！！！！！！！！这是MHA程序的问题！！！

创建必须目录

mkdir -p /etc/mha

mkdir -p /var/log/mha/app1 —-》可以管理多套主从复制

创建配置文件 （manager）(不需要的配置不要留着，注释没用,切换后会重写)

[root@db05 /var/log/mha/app1]# vim /etc/mha/app1.cnf

[server default]

manager_log=/var/log/mha/app1/manager

manager_workdir=/var/log/mha/app1

master_binlog_dir=/data/mysql

user=mha

password=mha

ping_interval=2

repl_password=123

repl_user=repl

ssh_user=root

[server1]

hostname=10.0.0.51

port=3306

[server2]

hostname=10.0.0.52

port=3306

[server3]

hostname=10.0.0.53

port=3306

配置互信(所有节点)

ssh-keygen -t dsa -P ” -f ~/.ssh/id_dsa >/dev/null 2>&1

ssh-copy-id -i /root/.ssh/id_dsa.pub root@10.0.0.51

ssh-copy-id -i /root/.ssh/id_dsa.pub root@10.0.0.52

ssh-copy-id -i /root/.ssh/id_dsa.pub root@10.0.0.53

ssh 10.0.0.51 date

ssh 10.0.0.52 date

ssh 10.0.0.53 date

自带脚本，检测互信

[root@db03 ~]# masterha_check_ssh –conf=/etc/mha/app1.cnf

检查复制环境
masterha_check_repl –conf=/etc/mha/app1.cnf

原因：是因为hosts解析的问题,初始化之前就加了解析就会有这问题

[error][/usr/share/perl5/vendor_perl/MHA/ServerManager.pm, ln301]

Got MySQL error when connecting 10.0.0.53(10.0.0.53:3306) :1045:Access denied for user ‘mha’@’server3’

(using password: YES), but this is not a MySQL crash. Check MySQL server settings.

解决：

我们需要在配置文件中加入

skip-name-resolve

启动mha

nohup masterha_manager –conf=/etc/mha/app1.cnf –remove_dead_master_conf –ignore_last_failover < /dev/null > /var/log/mha/app1/manager.log 2>&1 &

检查状态：
[root@server3 ~]# masterha_check_status –conf=/etc/mha/app1.cnf

app1 (pid:7502) is running(0:PING_OK), master:10.0.0.51

重要注意
set global relay_log_purge = 0;     临时（建议三个节点都做）

relay_log_purge = 0                 永久，在配置文件，建议在三个节点都做

set global read_only=1;             临时，为后续读写分离准备，不需要在配置文件生效（在所有从库）

对关键命令进行软连接（重要）

ln -s /usr/local/mysql/bin/mysqlbinlog /usr/bin/mysqlbinlog

ln -s /usr/local/mysql/bin/mysql /usr/bin/mysql

MHA启动前的检查（重要）：

masterha_check_ssh –conf=/etc/mha/app1.cnf

masterha_check_repl –conf=/etc/mha/app1.cnf

跳过域名解析（重要）：

我们需要在配置文件中加入 skip-name-resolve

开启MHA：

nohup masterha_manager –conf=/etc/mha/app1.cnf –remove_dead_master_conf –ignore_last_failover < /dev/null > /var/log/mha/app1/manager.log 2>&1 &

测试

模拟主库(db01)宕机

/etc/init.d/mysqld stop

监控manager日志/var/log/mha/app1/manager

MHA服务下,主库宕机 修复过程

1、db01，排查故障原因，处理故障，启动mysql

2、重新把db01作为从库的角色，加入到现有的主从环境

具体的命令可以通过日志文件获取

：/var/log/mha/app1/manager

CHANGE MASTER TO MASTER_HOST=’10.0.0.52′, MASTER_PORT=3306, MASTER_AUTO_POSITION=1, MASTER_USER=’repl’, MASTER_PASSWORD=’123′;

start slave;

3、将MHA重启配置启动

修改vim /etc/mha/app1.cnf

加入db01节点信息

[server1]

hostname=10.0.0.51

port=3306

开启MHA：

nohup masterha_manager –conf=/etc/mha/app1.cnf –remove_dead_master_conf –ignore_last_failover < /dev/null > /var/log/mha/app1/manager.log 2>&1 &

检查状态：

[root@server3 ~]# masterha_check_status –conf=/etc/mha/app1.cnf

以上的架构还缺少部分功能(vip sendmail binlog)
VIP功能实现：

向网管申请一个全新的VIP：这个IP一定是没有被使用(10.0.0.55/24)

将来得业务要指定连接这个VIP。

准备VIP漂移脚本

我们已经写好了，直接上传使用就可以了。

scripts.tar.gz ——> /usr/local/bin/

ip 漂移(mamanger节点)

（1）vim /usr/local/bin/master_ip_failover

my $vip = ‘10.0.0.55/24’;

my $key = ‘1’;

my $ssh_start_vip = “/sbin/ifconfig eth0:$key $vip”;

my $ssh_stop_vip = “/sbin/ifconfig eth0:$key down”;

(2)将vip功能加入app1.cnf

vi /etc/mha/app1.cnf

master_ip_failover_script=/usr/local/bin/master_ip_failover

(3)在主节点生成vip

ifconfig eth0:1 10.0.0.55/24

（4）测试

send_report

三个脚本

上传到db03 节点 /usr/local/bin中

vi /etc/mha/app1.cnf

report_script=/usr/local/bin/send

停止MHA

/usr/bin/masterha_stop –conf=/etc/mha/app1.cnf

启动MHA