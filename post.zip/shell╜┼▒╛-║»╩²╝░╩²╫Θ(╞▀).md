---
title: "Shell脚本 函数及数组(七)"
date: 2019-09-29T17:19:09+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
函数及数组
<!--more-->
数组的定义
查看数组

    [root@node3 /server/scripts]# arry=(1 2 3 4) 定义数组

    [root@node3 /server/scripts]# echo ${arry[*]} 查看变量的数组

    1 2 3 4

    [root@node3 /server/scripts]# echo ${arry[0]} 变量的第一是从0开始

    1

    [root@node3 /server/scripts]# echo ${arry[1]}

    2

    [root@node3 /server/scripts]# echo ${arry[2]}

    3

    [root@node3 /server/scripts]# unset arry[0] 删除变量的中的第一个数字

    [root@node3 /server/scripts]# echo ${arry[0]} 但是位置还在

    [root@node3 /server/scripts]# echo ${arry[1]}

    2

    [root@node3 /server/scripts]# arry[0]=7 重新赋予第一个数字

    [root@node3 /server/scripts]# echo ${arry[0]}

    7

    [root@node3 /server/scripts]# echo ${arry[*]}

    7 2 3 4

    [root@node3 /server/scripts]# echo ${#arry[*]} 统计变量的数组个数

    4

    [root@node3 /server/scripts]# unset arry 删除变量

    [root@node3 /server/scripts]# echo ${#arry[*]}

    0

遍历数组

    [root@node3 /server/scripts]# vim qwe.sh

        #!/bin/bash

        stu=(123 456 79)

        for i in ${stu[*]}

        do

        echo $i

        done


批量检查多个网站地址是否正常

    [root@node3 /server/scripts]# cat URL.sh

    #!/bin/bash

    dns=(http://blog.oldboyedu.com

    http://blog.etiantian.org

    http://oldboy.blog.51cto.com

    http://10.0.0.7)

    while true

    do

    for i in ${dns[*]}

    do

    a=$(curl -I -s -w “%{http_code}\n” -o /dev/null $i)

    if

    [ $a = “200” -o $a = 301 ];then

    echo $i 正常

    else

    echo $i 无法访问

    fi

    done

    echo ==========================================

    sleep 10

    done

函数使用

    [root@node3 /server/scripts]# vim fun.sh

    #!/bin/bash

    function eleven(){

    echo “hello word”

    }

    eleven

    [root@node3 /server/scripts]# sh fun.sh

    hello word

    [root@node3 /server/scripts]# vim fun.sh

    #!/bin/bash

    function eleven(){

    echo “hello word” $0 $1

    }

    eleven $1
通过传参传到调用函数,再传到函数

    [root@node3 /server/scripts]# sh fun.sh 65

    hello word fun.sh 65

调用fun.sh函数库

    [root@node3 /server/scripts]# vim fun.sh

    #!/bin/bash

    function eleven(){

    echo “hello word” $1

    }

    [root@node3 /server/scripts]# vim fun01.sh

    #!/bin/bash

    source /server/scripts/fun.sh ####调用函数库

    eleven $1
    传参

    [root@node3 /server/scripts]# sh fun01.sh 65

    hello word 65

    [root@node3 /server/scripts]# basename /server/scripts/fun.sh 提取脚本名字

    fun.sh

    [root@node3 /server/scripts]# basename /server/scripts/fun.sh .sh 取消脚本后缀

    fun

    [root@node3 /server/scripts]# dirname /server/scripts/fun.sh 提取脚本目录

    /server/scripts