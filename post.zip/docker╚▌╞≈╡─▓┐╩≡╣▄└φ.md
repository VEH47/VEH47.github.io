---
title: "Docker容器的部署管理"
date: 2019-09-29T10:48:50+08:00
tags: 
- docker
categories:
- docker
archives:
- docker
---
Docker是通过内核虚拟化技术（namespaces及cgroups cpu、内存、磁盘io等）来提供容器的资源隔离与安全保障等。
由于Docker通过操作系统层的虚拟化实现隔离，所以Docker容器在运行时，不需要类似虚拟机（VM）额外的操作系统开销，
提高资源利用率。
<!--more-->
### 1. docker容器

docker的主要目标是"Build,Ship and Run any App,Angwhere",构建，运输，处处运行
构建：做一个docker镜像
运输：docker pull
运行：启动一个容器
每一个容器，他都有自己的文件系统rootfs.

docker解决了软件和操作系统环境之间的依赖，能够让独立服务或应用程序在不同的环境中，得到相同的运行结果。
docker容器是一种轻量级、可移植、自包含的软件打包技术，使应用程序可以在几乎任何地方以相同的方式运行。开发人员
在自己笔记本上创建并测试好的容器，无需任何修改就能够在生产系统的虚拟机、物理服务器或公有云主机上运行。

### 2. docker的安装
    wget -O /etc/yum.repos.d/docker-ce.repo https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo
    sed -i 's#download.docker.com#mirrors.ustc.edu.cn/docker-ce#g' /etc/yum.repos.d/docker-ce.repo
-----
    vi /etc/yum.repos.d/docker-ce.repo
    [docker-ce-stable]
    name=Docker CE Stable - $basearch
    baseurl=https://mirrors.ustc.edu.cn/docker-ce/linux/centos/7/$basearch/stable
    enabled=1
    gpgcheck=0
    gpgkey=https://mirrors.ustc.edu.cn/docker-ce/linux/centos/gpg
    yum install docker-ce -y
    systemctl start docker.service

----
    vim /etc/sysctl.conf
    net.bridge.bridge-nf-call-ip6tables = 1
    net.bridge.bridge-nf-call-iptables = 1
    sysctl -p

### 3. docker的主要组成部分

docker是传统的CS架构分为docker client和docker server,像mysql一样

命令：docker version

    [root@controller ~]# docker version
    Client:
    Version: 17.12.0-ce
    API version: 1.35
    Go version: go1.9.2
    Git commit: c97c6d6
    Built: Wed Dec 27 20:10:14 2017
    OS/Arch: linux/amd64
    Server:
        Engine:
         Version: 17.12.0-ce
        API version: 1.35 (minimum version 1.12)
        Go version: go1.9.2
        Git commit: c97c6d6
        Built: Wed Dec 27 20:12:46 2017
        OS/Arch: linux/amd64
        Experimental: false
    docker  info   
  
### 4. docker的镜像管理

配置docker镜像加速
    vim /etc/docker/daemon.json

    {

        "registry-mirrors": ["https://registry.docker-cn.com"]

    }

搜索镜像: docker search

下载镜像: docker pull + 镜像:镜像版本

镜像加速器：阿里云加速器，daocloud加速器，中科大加速器，Docker 中国官方镜像加速：https://registry.docker-cn.com

第三方docker镜像仓库，使用方法：

    docker pull index.tenxcloud.com/tenxcloud/httpd:latest

查看镜像:  docker images

删除镜像:  docker rmi  

    例子：docker image rm centos:latest 或者docker  rmi centos:latest

导出镜像:  docker save  

    例子：docker image save centos > docker-centos7.4.tar.gz

导入镜像:   docker load  

    例子：docker image load -i docker-centos7.4.tar.gz

手动将容器保存为镜像:  docker commit

    例:docker commit b511b0a19f4a  kodexplorer4:v3
                      容器ID         新镜像名称

### 5. docker的容器管理

启动容器

docker   run        -d         -p 80:80  (可以指定多个端口) --restart=always     centos6-ssh-httpd:v1 /init.sh     
      创建带运行   后台运行    宿主端口:容器端口            总是重启                     容器名称

    docker run -it image_name:版本号  分配交互式终端进入容器
                
    docker run -it --name 名字 image_name:版本号   给容器取名

停止容器:  docker stop 容器名字或者ID

杀死容器:  docker kill  容器名字或者ID

查看容器:

    docker ps  查看在运行的容器

    docker ps –a  查看所有容器

进入容器:

    docker exec [OPTIONS] CONTAINER COMMAND [ARG...]

    docker exec -it be5f71a4356d /bin/bash
           分配一个终端 +容器id+ 前台进程

删除容器: docker rm -f be5f71a4356d

*总结：docker容器内的第一个进程必须一直处于前台运行的状态，否则这个容器，就会处于退出状态！*

### 6. docker容器的网络访问

指定映射:

    -p hostPort:containerPort
    -p ip:hostPort:containerPort 
    -p ip::containerPort
    -p hostPort:containerPort:udp
    -p 81:80 –p 443:443

随机映射:

    docker run -P
### 7. docker的数据卷管理
数据卷(文件或目录)

    -v /data
    -v src:dst

数据卷容器

--volumes-from

挂载

     -v /opt/myregistry:/var/lib/registry  
     -v       宿主机目录:容器里的目录

### 8. dockerfile自动构建docker镜像

dockerfile主要组成部分：

    基础镜像信息       FROM：centos:6.8
    制作镜像操作指令   RUN yum install openssh-server -y
    容器启动时执行指令 CMD ["/bin/bash"]

dockerfile常用指令：

    FROM 这个镜像的妈妈是谁？（指定基础镜像）
    RUN 你想让它干啥（在命令前面加上RUN即可）
    ADD 给它点创业资金（COPY文件，会自动解压只能解压tar包）
    WORKDIR 我是cd,今天刚化了妆（设置当前工作目录）
    VOLUME 给它一个存放行李的地方（设置卷，挂载主机目录）
    EXPOSE 它要打开的门是啥（指定对外的端口）	
    COPY 复制文件
    ENV  环境变量  (设置时,需要在执行脚本里设置环境变量)
    ENTRYPOINT  容器启动后执行的命令(不管加什么都不会被替换)
    CMD 奔跑吧，兄弟！（指定容器启动后的要干的事情,命令容易被替换）
    MAINTAINER 告诉别人，谁负责养它？（指定维护者信息，可以没有）

例:

    [root@docker01 /Dockerfile]# cat Dockerfile        ####必须这个名字
    FROM centos:6.8                                ####指定镜像
    COPY  CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo   ####把宿主机当前目录的文件复制到容器里的目录下
    RUN yum install openssh-server -y             ####下载软件  
    RUN yum install httpd -y                     #### 下载软件
    RUN yum install php* unzip -y
    WORKDIR  /var/www/html                         ####进入这个目录,以后的操作都在这个目录下
    RUN curl -o kodexplorer.zip http://static.kodcloud.com/update/download/kodexplorer4.25.zip   ####下载这个软件
    RUN unzip kodexplorer.zip                     #### 解压这个软件
    RUN chmod -R 777 ./                          ####  授予当前目录777权限
    RUN /etc/init.d/sshd start                    #### 启动ssh服务     
    ADD init.sh /init.sh                           ####在当前目录下的脚本 cp到容器中的根下生成脚本
    ENTRYPOINT ["/bin/bash","/init.sh"]           #### 执行脚本并且首次启动容器命令不变
-----
    [root@docker01 /Dockerfile]# cat init.sh       ####上边的脚本
    #!/bin/bash 
    /etc/init.d/httpd start                        ####启动服务
    echo "root:${ssh_passwd}"|chpasswd            #### (用环境变量给设置密码)
    /usr/sbin/sshd -D                              ####夯住容器
  
创建镜像

    docker build -t centos6-sshd:v5 .              ####指定当前目录下的 Dockerfile  

创建容器(生成容器 指定密码)

    docker run -d -p 10062:22 -p 82:80 --restart=always  --env "ssh_passwd=qwer1234" centos6-ssh-httpd:v4 


### 9. 容器间的互联
    docker run -d -p 80:80 nginx
    docker run -it --link quirky_brown:web01 qstack/centos-ssh /bin/bash
    ping web01

使用docker运行zabbix-server

     docker run --name mysql-server -t \
      -e MYSQL_DATABASE="zabbix" \
      -e MYSQL_USER="zabbix" \
      -e MYSQL_PASSWORD="zabbix_pwd" \
      -e MYSQL_ROOT_PASSWORD="root_pwd" \
      -d mysql:5.7 \
      --character-set-server=utf8 --collation-server=utf8_bin
----------
    docker run --name zabbix-java-gateway -t \
      -d zabbix/zabbix-java-gateway:latest
------------
    docker run --name zabbix-server-mysql -t \
      -e DB_SERVER_HOST="mysql-server" \
      -e MYSQL_DATABASE="zabbix" \
      -e MYSQL_USER="zabbix" \
      -e MYSQL_PASSWORD="zabbix_pwd" \
      -e MYSQL_ROOT_PASSWORD="root_pwd" \
      -e ZBX_JAVAGATEWAY="zabbix-java-gateway" \
      --link mysql-server:mysql \
      --link zabbix-java-gateway:zabbix-java-gateway \
      -p 10051:10051 \
      -d zabbix/zabbix-server-mysql:latest
------------
    docker run --name zabbix-web-nginx-mysql -t \
      -e DB_SERVER_HOST="mysql-server" \
      -e MYSQL_DATABASE="zabbix" \
      -e MYSQL_USER="zabbix" \
      -e MYSQL_PASSWORD="zabbix_pwd" \
      -e MYSQL_ROOT_PASSWORD="root_pwd" \
      --link mysql-server:mysql \
      --link zabbix-server-mysql:zabbix-server \
      -p 80:80 \
      -d zabbix/zabbix-web-nginx-mysql:latest

### 10. docker registry(镜像仓库)
##普通的registry

    docker run -d -p 5000:5000 --restart=always --name registry -v /opt/myregistry:/var/lib/registry  registry
   --restart=always    总是重启(docker服务重启后,这个容器依然重启)

   -v /opt/myregistry:/var/lib/registry  挂载 -v   宿主机目录:容器里的目录

例:
打成tag包作标签

    docker tag centos6-sshd:v6 10.0.0.11:5000/centos6-sshd:v6  
    [root@docker01 ~]# cat -A /etc/docker/daemon.json  ####修改文件
    {$
    "registry-mirrors": ["https://registry.docker-cn.com"],$
    "insecure-registries" : ["10.0.0.11:5000"]$
    }$
systemctl restart docker.service            ####重启docker服务

docker push 10.0.0.11:5000/centos6-sshd:v6  ####推送到本地库

其他服务器下载

修改文件

    [root@docker02 ~]# cat -A /etc/docker/daemon.json  
    {$
    "registry-mirrors": ["https://registry.docker-cn.com"],$
    "insecure-registries" : ["10.0.0.11:5000"]$
    }$
systemctl restart docker.service           重启docker服务

docker pull 10.0.0.11:5000/centos6-sshd:v6  下载镜像


##带basic认证的registry

    yum install httpd-tools -y   
    mkdir /opt/registry-var/auth/ -p
    htpasswd  -Bbn oldboy 123456  >> /opt/registry-var/auth/htpasswd
    docker run -d -p 5000:5000 --name registry- -v /opt/registry-var/auth/:/auth/ -v /opt/myregistry:/var/lib/registry -e "REGISTRY_AUTH=htpasswd" -e "REGISTRY_AUTH_HTPASSWD_REALM=Registry Realm" -e REGISTRY_AUTH_HTPASSWD_PATH=/auth/htpasswd registry:latest
    docker commit fa676343be50 registry           ####将容器做成镜像
    docker tag registry 10.0.0.11:5000/reistry    ####将镜像打成tag包标签(需要指定ip)
    docker login http://10.0.0.11:5000            ####登录仓库
    docker push 10.0.0.11:5000/reistry           #### 推送到本地库

在其他服务器

    [root@docker02 ~]# docker login http://10.0.0.11:5000
    Username: oldboy
    Password: 123456
    Login Succeeded

    拉镜像 docker pull 10.0.0.11:5000/reistry

### 17. docker-compose(单机版的容器编排工具)
    yum install -y python2-pip

    pip install docker-compose

##pip 加速
    pip install -i https://pypi.tuna.tsinghua.edu.cn/simple  docker-compose

##详细指令: http://www.jianshu.com/p/2217cfed29d7

    cd my_wordpress/
    vi docker-compose.yml
    version: '3'
    services:
     db:
     image: mysql:5.7
     volumes:
       - db_data:/var/lib/mysql
     restart: always
     environment:
       MYSQL_ROOT_PASSWORD: somewordpress
       MYSQL_DATABASE: wordpress
       MYSQL_USER: wordpress
       MYSQL_PASSWORD: wordpress

    wordpress:
     depends_on:
       - db
     image: wordpress:latest
     ports:
       - "80"
     restart: always
     environment:
       WORDPRESS_DB_HOST: db:3306
       WORDPRESS_DB_USER: wordpress
       WORDPRESS_DB_PASSWORD: wordpress
    volumes:
    db_data:

#启动

docker-compose up

#后台启动

docker-compose up -d

docker-compose scale wordpress=3

###haproxy

    yum install haproxy -y

    vi /etc/haproxy/haproxy.cfg
    global
    log         127.0.0.1 local2
    chroot      /var/lib/haproxy
    pidfile     /var/run/haproxy.pid
    maxconn     4000
    user        haproxy
    group       haproxy
    daemon
    stats socket /var/lib/haproxy/stats level admin
    defaults
        mode                    http
        log                     global
        option                  httplog
        option                  dontlognull
        option http-server-close
        option forwardfor       except 127.0.0.0/8
        option                  redispatch
        retries                 3
        timeout http-request    10s
        timeout queue           1m
        timeout connect         10s
        timeout client          1m
        timeout server          1m
        timeout http-keep-alive 10s
        timeout check           10s
        maxconn                 3000
    listen stats
        mode http
        bind 0.0.0.0:8888
        stats enable
        stats uri     /haproxy-status 
        stats auth    admin:123456
    frontend frontend_www_example_com
        bind 10.0.0.11:8000
        mode http
        option httplog
        log global
        default_backend backend_www_example_com
    backend backend_www_example_com
        option forwardfor header X-REAL-IP
        option httpchk HEAD / HTTP/1.0
        balance roundrobin
        server web-node1  10.0.0.11:32768 check inter 2000 rise 30 fall 15
        server web-node2  10.0.0.11:32769 check inter 2000 rise 30 fall 15
        server web-node3  10.0.0.11:32770 check inter 2000 rise 30 fall 15

    systemctl start haproxy	

访问 10.0.0.11:8888/haproxy-status

	  10.0.0.11:8000

##安装socat	

    yum install socat.x86_64 -y
    echo "disable server backend_www_example_com/web-node3"|socat stdio /var/lib/haproxy/stats
    echo "enable server backend_www_example_com/web-node3"|socat stdio /var/lib/haproxy/stats

##测试页

    cat >test.php <<'EOF'
    <html>
        <head>
            <title>PHP测试</title>
        </head>
        <body>
            <?php  echo '<p>Hello World </p>'; ?>
            <?php  echo "访问的服务器地址是:"."<fontcolor=red>".$_SERVER['SERVER_ADDR']."</font>"."<br>";
            echo"访问的服务器域名是:"."<fontcolor=red>".$_SERVER['SERVER_NAME']."</font>"."<br>";
            ?>
        </body>
    </html>
    EOF


### 18. 重启docker服务，容器全部退出的解决办法
方法一：docker run  --restart=always

方法二："live-restore": true

docker server配置文件

    vim /etc/docker/daemon.json

    {
        "registry-mirrors": ["http://b7a9017d.m.daocloud.io"],
        "graph": "/opt/mydocker",
         "insecure-registries":["10.0.0.11:5000"],
        "live-restore": true
    }

### 20. Docker网络类型
None：不为容器配置任何网络功能，--net=none

Container：与另一个运行中的容器共享Network Namespace，--net=container:containerID

Host：与主机共享Network Namespace，--net=host

Bridge：Docker设计的NAT网络模型

 Docker跨主机通信之macvlan

##创建macvlan网络

    docker network create --driver macvlan --subnet 10.1.0.0/24 --gateway 10.1.0.254 -o parent=eth1 macvlan_1
##设置eth0的网卡为混杂模式

    ip link set eth1 promisc on
##创建使用macvlan网络的容器

    docker run -it --network macvlan_1 --ip=10.1.0.210 busybox:latest /bin/sh

作业2：用PIPEWORK为docker容器配置独立IP

### 22. Dcoker跨主机通信之overlay
http://www.cnblogs.com/CloudMan6/p/7270551.html

1)准备工作

docker01上：

    docker run -d -p 8500:8500 -h consul --name consul progrium/consul -server -bootstrap

docker02、03上：

    vim  /etc/docker/daemon.json
    {
        "hosts":["tcp://0.0.0.0:2376","unix:///var/run/docker.sock"],
        "registry-mirrors": ["https://registry.docker-cn.com"],
        "cluster-store": "consul://10.0.0.11:8500",
        "cluster-advertise": "10.0.0.12:2376",
        "insecure-registries": ["10.0.0.11:5000"]
    }

2）创建overlay网络

    docker network create -d overlay ol1

3）启动容器测试
    docker run -it --network ol1 --name oldboy02  busybox:latest /bin/sh


### 23. docker企业级镜像仓库harbor
第一步：安装docker和docker-compose

第二步：下载harbor-offline-installer-v1.3.0.tgz

第三步：上传到/opt,并解压

第四步：修改harbor.cfg配置文件

    hostname = 10.0.0.11
    harbor_admin_password = 123456

第五步：执行install.sshd

第六步: 登录仓库 docker login  10.0.0.11

第七步: 把镜像打成tag包并推送 docker tag centos:6.8 10.0.0.11/eleven/centos6 (注意格式 ip/项目/名称)

第八步: 推送 docker push 10.0.0.11/eleven/centos6:latest


设置docker远程执行

systemd详解：http://www.ruanyifeng.com/blog/2016/03/systemd-tutorial-part-two.html

####在linux-node1：

    vim /usr/lib/systemd/system/docker.service
    ExecStart=/usr/bin/dockerd -H unix:///var/run/docker.sock -H tcp://10.0.0.11:2375
    systemctl daemon-reload
    systemctl restart docker.service
ps -ef检查


