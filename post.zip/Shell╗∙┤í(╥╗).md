---
title: "Shell基础(一)"
date: 2019-09-29T17:14:35+08:00
tags: 
- 运维
- shell
categories:
- shell
archives:
- shell
---
基础的shell脚本, 适合新手入门,但是想要写的好, 就需要多多练习
<!--more-->

什么是变量

变量就是用一个固定的字符串（也可能是字符数字等的组合），替代更多复杂的内容，这个内容里可能还会包含变量和路径，字符串等其他内容。变量的定义是存在内存中

变量书写要求

一般是字母、数字、下划线组成，且以字母开头。如oldboy，oldboy123，oldboy_traning。变量的内容，可以使用单引号或双引号引起来，或不加引号. 虽然变量可以以下划线开头，但类似这种变量都是比较特殊的，都是系统自己用的。我们尽量少用。

变量的分类

环境变量（全局变量）：
可以在创建他们的Shell及其派生出来的子Shell中使用。环境变量又可以分为自定义环境变量和bash内置的环境变量

查看全局变量

    [root@node3 /server/scripts]# env

定义全局变量

    [root@node3 /server/scripts]# export hkx=1
-----------------
    [root@node3 /server/scripts]# cat hkx.sh
    #!/bin/bash
    ######################################################
    #File Name: hkx.sh
    #Version: V1.0
    #Author: Eleven
    #Organization: 2415069806
    #Created Time : 2018-01-24 09:23:14
    #Description:
    ##############################################################

echo $hkx

    [root@node3 /server/scripts]# sh hkx.sh

    1

    [root@node3 /server/scripts]# env |grep hkx

    hkx=1

删除变量

    [root@node3 /server/scripts]# unset hkx

    [root@node3 /server/scripts]# env |grep hkx

环境变量的知识小结：

❶变量名通常要大写。

❷变量可以在自身的Shell及子Shell中使用。

❸常用export来定义环境变量。

❹执行env默认可以显示所有的环境变量名称及对应的值

❺输出时用”$变量名”，取消时用”unset变量名”。

❻写crond定时任务时要注意，脚本要用到的环境变量最好先在所执行的Shell脚本中重新定义。

❼如果希望环境变量永久生效，则可以将其放在用户环境变量文件或全局变量文件里

普通变量（局部变量）：

只能在创建他们的Shell函数或Shell脚本中使用，关闭当前shell窗口则无法使用.我们创建的一般都是普通变量

特殊变量：位置变量和进程变量


$0：获取当前执行的shell脚本的文件名，如果执行脚本带路径那么就包括脚本路径。

$n：获取当前执行的shell脚本的第n个参数值，n=1..9，当n为0时表示脚本的文件名，如果n大于9用大括号括起来{10}，参数以空格隔开。

$#：获取当前执行的shell脚本后面接的参数的总个数

$*：获取当前shell的所有传参的参数，不加引号同$@;如果给$*加上双引号，例如：”$*”,则表示将所有参数视为单个字符串，相当于”$1$2$3″

$@: 获取当前shell的所有传参的参数,不加引号同$*.如果给$@加上双引号,例如”$@”则表示将所有参数视为不同的独立的字符串. 相当于”$1″ “$2″”$3″”••••••”，这是将参数传递给其他程序的最佳方式，因为他会保留所有内嵌在每个参数里任何空白。

当”$*”和”$@”都加双引号时，两者有区别，都不加双引号时，两者无区别。

位置变量$0 $n

    [root@node3 /server/scripts]# cat hkx.sh
    #!/bin/bash
    ##############################################################
    #File Name: hkx.sh
    #Version: V1.0
    #Author: Eleven
    #Organization: 2415069806
    #Created Time : 2018-01-24 09:23:14
    #Description:
    ##############################################################
    echo $0 显示脚本名称,并且随着脚本名称而改变
    echo $1
    echo $2
    echo $3
    echo $4
    echo $5
    echo $6
    echo $7
    echo $8
    echo $9
    echo ${10}

当变量超过9时需要把变量用大括号括起来

    [root@node3 /server/scripts]# sh hkx.sh s zdf zdr srg n sg srth tgh rth cfg
    hkx.sh
    s
    zdf
    zdr
    srg
    n
    sg
    srth
    tgh
    rth
    cfg

位置变量$#

    [root@node3 /server/scripts]# sh hkx.sh 3
    1
    dui

    [root@node3 /server/scripts]# cat hkx.sh
    #!/bin/bash
    ##############################################################
    #File Name: hkx.sh
    #Version: V1.0
    #Author: Eleven
    #Organization: 2415069806
    #Created Time : 2018-01-24 09:23:14
    #Description:
    ##############################################################
    #echo $#
    #定义使用脚本参数(个数)

    if
    [ $# -eq 1 ];then ###如果使用脚本参数等于1,则显示dui否则显示baocuo并且退出显示2
    echo dui
    else
    echo baocuo && exit 2
    fi

例

    [root@node3 /server/scripts]# sh hkx.sh 3
    1 (一个参数的意思)
    dui

例

    [root@node3 /server/scripts]# sh hkx.sh 23 84
    2 (两个参数)
    baocuo 显示baocuo并结束

$*和$@的用法, 建议使用”$@”

    [root@node3 /server/scripts]# set — 1
    “2 3”
    4..
定义三个临时局部变量

    [root@node3 /server/scripts]# echo $0

    -bash 当前的窗口是bash

    [root@node3 /server/scripts]# echo $1

    1

    [root@node3 /server/scripts]# echo $2

    2 3

    [root@node3 /server/scripts]# echo $3

    4..

    [root@node3 /server/scripts]# echo $* 不符合要求

    1 2 3 4..

    [root@node3 /server/scripts]# echo $@

    1 2 3 4..

    [root@node3 /server/scripts]# echo “$@”

    1 2 3 4..

    [root@node3 /server/scripts]# echo “$*”

    1 2 3 4..

    [root@node3 /server/scripts]# for i in $*;do echo $i;done

    1

    2

    3

    4..

    [root@node3 /server/scripts]# for i in $@;do echo $i;done

    1

    2

    3

    4..

    [root@node3 /server/scripts]# for i in “$*”;do echo $i;done

    1 2 3 4..

    [root@node3 /server/scripts]# for i in “$@”;do echo $i;done

    1

    2 3

    4..