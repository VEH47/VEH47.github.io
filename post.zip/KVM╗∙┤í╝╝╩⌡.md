---
title: "KVM基础技术"
date: 2019-09-29T14:13:51+08:00
tags: 
- KVM
categories:
- KVM
archives:
- KVM
---
什么是虚拟化？
虚拟化，是指通过虚拟化技术将一台计算机虚拟为多台逻辑计算机。在一台计算机上同时运行多个逻辑计算机，每个逻辑计算机可运行不同的操作系统，并且应用程序都可以在相互独立的空间内运行而互不影响，从而显著提高计算机的工作效率
<!--more-->

虚拟化使用软件的方法重新定义划分IT资源，可以实现IT资源的动态分配、灵活调度、跨域共享，提高IT资源利用率，使IT资源能够真正成为社会基础设施，服务于各行各业中灵活多变的应用需求。

为什么要用虚拟化
虚拟化：提高了资源的利用率，服务的安全性隔离，解决了系统和硬件之间的依赖

场景1：同一台物理机运行多个php版本

场景2：机房的迁移，解决了硬件和系统的依赖

场景3：openstack环境，软件发布体检

场景4：开发环境和测试环境，使用虚拟化

场景5：业务的快速部署

kvm虚拟化软件的安装(KVM：Kernel-based Virtual Machine )

yum install libvirt* virt-* qemu-kvm* -y

libvirt 作用：虚拟机的管理软件

virt virt-install virt-clone 作用：虚拟机的安装和克隆

qemu-kvm qemu-img 作用：复制管理虚拟机的磁盘

虚拟化软件：

qemu 软件纯模拟全虚拟化软件，特别慢！

xen(半) 性能特别好，需要使用专门修改之后的内核

KVM 全虚拟机，它有硬件支持cpu，基于内核，而且不需要使用专门的内核

安装一台虚拟机

systemctl start libvirtd.service 启动

systemctl status libvirtd.service 查看状态

建议虚拟机内存不要低于1024M，否则安装系统特别慢！

virt-install –virt-type kvm –os-type=linux –os-variant rhel7 –name centos7 –memory 1024 –vcpus 1 –disk /opt/centos7.raw,format=raw,size=10 –cdrom /opt/CentOS-7-x86_64-DVD-1708.iso –network network=default –graphics vnc,listen=0.0.0.0 –noautoconsole

raw：10G 不支持做快照，性能好

qcow2：
支持快照

kvm虚拟机的virsh日常管理和配置
virsh list centos7 显示列表

virsh start centos7 开机

virsh shutdown centos7 关机

virsh destory centos7 拔电源关机

virsh suspeng centos7 挂起

virsh resume centos7 恢复

virsh vncdisplay centos7 查询vnc端口

导出配置dumpxml 例子：virsh dumpxml centos7 >centos7-off.xml

导入配置define 例子virsh define centos7-off.xml

修改配置edit(自带语法检查) virsh edit centos7

删除undefine 推荐：先destroy，在undefine 例virsh undefine centos7

重命名domrename （低版本不支持）

kvm虚拟机开机启动和console登录
开机启动autostart，前提：systemctl enable libvirtd；

virsh autostart centos7

取消开机启动autostart –disable

virsh autostart –disable centos7

centos7的kvm虚拟机：

grubby –update-kernel=ALL –args=”console=ttyS0,115200n8″

reboot

登录: virsh console centos7

kvm虚拟机虚拟磁盘格式转换和快照管理

virt-install –virt-type kvm –os-type=linux –os-variant rhel7 –name centos7 –memory 1024 –vcpus 1 –disk /opt/oldboy.qcow2,format=qcow2,size=10 –cdrom /etc/opt/CentOS-7.2-x86_64-DVD-1511.iso –network network=default –graphics vnc,listen=0.0.0.0 –noautoconsole

raw：裸格式，占用空间比较大，不支持快照功能，性能较好，

qcow2：cow （copy on write）占用空间小，支持快照，性能比raw差一点

创建一块qcow2格式的虚拟硬盘并指定大小

qemu-img create -f qcow2 test.qcow2 2G

查看test.qcow2 这个文件的详细信息(也可以查看raw格式的)

qemu-img info test.qcow2

raw格式转qcow2格式 (最好处于关机状态)

qemu-img convert -f raw -O qcow2 oldboy.raw oldboy.qcow2

原文件格式
转换为qco2格式
原文件
转换后的文件

想要使用新的磁盘格式修改配置文件

virsh edit centos7：

<disk type=’file’ device=’disk’>

<driver name=’qemu’ type=’qcow2’/>

<source file=’/opt/oldboy.qcow2’/>

<target dev=’vda’ bus=’virtio’/>

<address type=’pci’ domain=’0x0000′ bus=’0x00′ slot=’0x06′ function=’

0x0’/>

</disk>

创建快照virsh snapshot-create centos7

查看快照virsh snapshot-list centos7

还原快照virsh snapshot-revert centos7 –snapshotname 1516574134

删除快照virsh snapshot-delete centos7 –snapshotname 1516636570

kvm虚拟机克隆
virt-clone –auto-clone -o centos7(完整克隆)

kvm虚拟机的桥接网络
### 1. virsh iface-bridge eth0 br0

### 2. virsh edit centos7

<interface type=’bridge’>

<mac address=’52:54:00:55:aa:fa’/>

<source bridge=’br0’/>

在宿主机上，重启虚拟机生效

### 3. 修改kvm虚拟机的ip

echo ‘TYPE=Ethernet

BOOTPROTO=static

NAME=eth0

DEVICE=eth0

ONBOOT=yes

IPADDR=10.0.0.111

NETMASK=255.255.255.0

GATEWAY=10.0.0.254

DNS1=223.5.5.5’ >/etc/sysconfig/network-scripts/ifcfg-eth0

### 4. 验证:登录测试,

ping www.baidu.com

kvm虚拟机在线热添加硬盘
创建一块硬盘

qemu-img create -f qcow2 centsos-add01.qcow2 5G

添加硬盘

virsh attach-disk centos7 /opt/centos7-add01.qcow2 vdb –live –cache=none –subdriver=qcow2

去除添加的硬盘

virsh detach-disk centos7 vdb

虚拟机磁盘扩容：

在kvm虚拟机，卸载

virsh detach-disk centos7 vdb

给vdb添加5G空间

qemu-img resize /opt/centos7-add01.qcow2 +5G

重新添加撒谎那个硬盘

virsh attach-disk centos7 /opt/centos7-add01.qcow2 vdb –live –cache=none –subdriver=qcow2

在虚拟机中格式化新加载的磁盘

mkfs.xfs /dev/vdb

在虚拟机上挂载

mount /dev/vdb /tmp

根分区扩容：

1）在宿主机上关闭虚拟机并调整虚拟机磁盘大小

qemu-img resize oldboy.qcow2 +10G

2）虚拟机中fdisk重新分区

fdisk /dev/vda

3)重启之后，执行xfs_growfs /dev/vda1，

如果虚拟机磁盘文件系统是ext4：resize2fs /dev/vda1

virt-manager和kvm虚拟机热迁移(共享的网络文件系统)部署
1):

yum groupinstall “GNOME Desktop” -y

yum install openssh-askpass -y

yum install tigervnc-server -y

vncpasswd 设置密码

vncserver :1 开启

vncserver -kill :1 关闭

2):kvm虚拟机热迁移

1：两边的环境（桥接网卡）

2：实现共享存储（nfs）

3：虚拟机桥接网络

4：在线热迁移

kvm虚拟机冷迁移
先关闭虚拟机
virsh shutdown centos7

保证两台服务器环境一致
现有的服务器是使用桥接网络,所以新服务器也必须使用桥接网络

virsh iface-bridge eth0 br0

导出配置文件
virsh dumpxml centos7 >/opt/centos7.xml

把配置文件与磁盘文件一起发往新服务器
发出的磁盘文件和配置文件路径必须一致

scp /opt/centos7.xml 10.0.0.12:/opt/

scp /opt/oldboy.raw 10.0.0.12:/opt/

在新服务器导入配置文件
新服务器不许开启虚拟化设置

virsh define /opt/centos7.xml

virsh start centos7 启动

生产中CPU可能不同,需要解决兼容性问题