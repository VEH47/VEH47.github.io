---
title: "Linux高级路由"
date: 2019-09-29T15:39:45+08:00
tags:
- 网络
- 策略路由
categories:
- 网络
archives:
- 网络
---
路由策略数据库的规则用于控制选择路由的算法。

Internet上采用的路由算法一般是基于数据包目的地址的。理论上，也可以由TOS域决定，不过这没有实际应用。要了解经典路由算法的详细情况请参考RFC-1812。
<!--more-->
而在某些情况下，我们不只是需要通过数据包的目的地址决定路由，可能还需要通过其他一些域：源地址、IP协议、传输层端口甚至数据包的负载。这就叫做：策略路由(policy routing)。

注意：策略路由(policy routing)不等于路由策略(rouing policy)。

在这种情况下，传统的基于目的地址的路由表就无法满足要求了，需要使用路由策略数据库(routing policy database,RPDB)代替，通过它选择执行某些路由。这些规则可以由很多不同的状态，而且它们没有天生的次序，要由系统管理员决定。RPDB可以 匹配以下的域:

 

数据包的源地址；

数据包的目的地址；

服务类型(Type of Service)；

进入的网络接口；

匹配IP协议和传输层端口也是可能的，不过这要依靠iptables或者ipchains通过fwmark为某些数据包做标记，并重定向。

每个路由策略由一个选择符(selector)和一个操作(action)组成。系统按照顺序搜索路由策略数据库，把选择符和{源地址、目的地址、进入 接口、tos、fwmark}等关键词进行匹配，如果匹配成功，就执行action定义的操作。操作或者成功返回，或者失败并且中止对路由策略。否则，系 统继续查询路由策略数据库。

操作如何定义？最原始的操作是选择下一跳(nexthop)和输出设备(output device)。Cisco IOS使用这种方式，我们姑且把这叫做匹配并设置(match & set)。而Linux的方式则更为灵活，Linux允许的操作包括：基于目的地址的路由表查询以及按照最长匹配的原则从路由表中选择路由。因此，匹配并 设置(match & set)的方式只是一个最简单的特例而已。

在系统启动时，内核会为路由策略数据库配置三条缺省的规则：

优先级 选择符 操作 解释   

local是我们最常使用的路由表，默认的路由表

0 匹配任何条件 查询路由表local(ID 255)路由表local是一个特殊的路由表，包含对于本地和广播地址的高优先级控制路由。rule 0非常特殊，不能被删除或者覆盖。

32766 匹配任何条件 查询路由表main(ID 254) 路由表main(ID 254)是一个通常的表，包含所有的无策略路由。系统管理员可以删除或者使用

另外的规则覆盖这条规则。

32767 匹配任何条件 查询路由表default(ID 253) 路由表default(ID 253)是一个空表，它是为一些后续处理保留的。对于前面的缺省策略没有匹配到的数据包，系统使用这个策略进行处理。这个规则也可以删除。

不要混淆路由表和策略：规则指向路由表，多个规则可以引用一个路由表，而且某些路由表可以没有策略指向它。如果系统管理员删除了指向某个路由表的所有规则，这个表就没有用了，但是仍然存在，直到里面的所有路由都被删除，它才会消失。

规则类型

路由策略规则数据库可以包括如下类型的规则：

unicast 返回从被引用的路由表中发现的路由。

blackhole 丢弃数据包，不做任何反应。

unreachable 产生网络不可达(Network is unreachable)的ICMP错误信息 。

prohibit 产生通讯被禁止(Communication is administratively prohibited)的ICMP错误信息。

nat 把数据报的源地址转换为其它的值。详情请参考附录C。

命令

add、delete、show(或者list)

ip rule add — 插入新的规则。

ip rule delete — 删除规则。

add、a；delete、del、d

 
参数

type TYPE(default)： 这个规则的类型。有效的类型上一节已经介绍过了。

from PREFIX： 匹配的源地址

iif NAME： 选择数据包进入的设备。如果接口是回环设备，这个规则就只匹配源于本机的数据包。这意味着，你可以为本机发出的数据包和要转发的数据包分别建立路由表，使两者完全隔离。

tos TOS或者dsfield TOS： 选择匹配的TOS值

fwmark MARK： 选择要匹配的fwmark值

priority PREFERENCE： 设置这个规则的优先级。每个规则的优先级都应该明确设置为一个唯一的数值。实际上，由于历史的原因，ip roule add命令无需任何优先级的值，也不必是唯一的。如果用户没有在命令中提供优先级的值，内核会自动选择。如果用户提供的优先级值已经存在，内核也不会拒绝这次请求，而是在相同优先级的规则前面插入新的规则。

table TABLEID： 如果规则选择符匹配，就被查询的路由表识别符。

realms FROM/TO： 如果规则匹配和路由表查询成功，选择的realms值。

nat ADDRESS： 设置要进行网络地址转换的IP地址段。ADDRESS或者是进行网络地址转换ip地址段，或者是一个本机地址，甚至可以是0。

警告：使用上面两个命令对路由策略数据库进行的任何修改都不会马上生效。只有使用ip route flush cach命令刷新路由缓存之后才会生效。

示例

通过路由表inr.ruhep路由来自源地址为192.203.80/24的数据包

ip ru add from 192.203.80/24 table inr.ruhep prio 220

 
把源地址为193.233.7.83的数据报的源地址转换为192.203.80.144，并通过表1进行路由

ip ru add from 193.233.7.83 nat 192.203.80.144 table 1 prio 320

删除无用的缺省规则

ip ru del prio 32767

注：32767和32766都可以删除，而0是不可以删除的。

 
ip rule show — 列出路由规则

缩写：show、list、sh、ls、l

输出格式

kuznet@amber:~ $ ip ru ls

0: from all lookup local

200: from 192.203.80.0/24 to 193.233.7.0/24 lookup main

210: from 192.203.80.0/24 to 192.203.80.0/24 lookup main

220: from 192.203.80.0/24 lookup inr.ruhep realms inr.ruhep/radio-msu

300: from 193.233.7.83 to 193.233.7.0/24 lookup main

310: from 193.233.7.83 to 192.203.80.0/24 lookup main

320: from 193.233.7.83 lookup inr.ruhep map-to 192.203.80.144

32766: from all lookup main

kuznet@amber:~ $

 
每行第一部分的数字是规则的优先级，接着是选择符。关键词lookup后面接着路由表识别符。如果规则要进行网络地址转换，还需要一个关键词map-to设置转换以后的地址。

上面的示例非常简单，192.203.80.0/24和193.233.7.0/24组成内部网络，但是它们向外发送数据包要通过不同的路由。主机193.233.7.83和外界会话时，地址需要转换为192.203.80.144。

 
linux的路由表与路由策略

ip route 只是基于目的地址的路由选择

ip rule 路由策略,控制路由选择，可根据源地址，源IP等进行路由选择

 
路由策略由选择符合操作组成

ip rule add   添加策略

ip rule delete  删除策略

ip rule show  显示策略

使用路由策略可以更好的控制路由走向，类似于cisco下的 route map

 
下面一个例子显示了使用路由策略的优点：

假设有一台双线服务器

有两张网卡，有电信IP和网通IP地址，实现电信IP访问服务器时，服务器响应使用电信网关，网通IP访问服务器时，服务器响应使用网通网关。

假设电信IP为

222.73.121.100/24 网关 222.73.121..1

网通IP

112.80.1.100/24 网关 112.80.1.1


方法1（静态路由方法）：

A. 使用电信网关做默认路由，并添加网通的路由条目，并将条目写到/etc/rc.local或者/etc/sysconfig/network里面，以开机时可以加载

在network里面添加GATEWAY=222.73.121.1

添加路由条目如下

route add –net 58.16.0.0/13 gw 112.80.1.1

B. 每网卡路由：假设eth0为222.73.121.100/24,eth1为112..80.1.100/24，新建以下文件

/etc/sysconfig/network-scripts/route-eth1

按如下格式添加路由条目

58.16.0.0/13 via 112.80.1.100

缺点是需要添加很多条目的路由条目，并且需要更新，如果有一个网通网段未添加，这个网段的IP就不能访问服务器的。

方法2(根据用户访问的路径设置静态路由):

1． 先在/etc/sysconfig/network里面添加默认路由GATEWAY=222.73.121.1

2． 设置ip rule 策略

vi /etc/iproute2/rt_tables #添加路由表

    [root@lamp iproute2]# cat rt_tables
    #
    # reserved values
    #
    255     local
    254     main
    253     default
    0       unspec
    252 dianxin   #电信路由表
    251 wangtong   #网通路由表
    #
    # local
    #
    #1      inr.ruhep

3． 添加原路返回路由

ip  route  flush  table dianxin

ip  route  add  default  via 222.73.121.1 dev  eth0  src 222.73.121.100 table dianxin

ip  rule  add  from  222.73.121.100  table  dianxin

ip route flush table wangtong

ip  route  add  default  via 112.80.1.1 dev eth1  src 112.80.1.100 table wangtong

ip  rule  add  from  112.80.1.100  table  wangtong

 
即让从电信IP过来的请求按照电信路由返回，从网通IP过来的请求从网通路由返回

将上述命令添加至/etc/rc.local中，以便重启可以生效

    [root@lamp ~]# ip rule show

    0:      from all lookup 255

    32764: from 112.80.1.100 lookup wangtong

    32765: from 222.73.121.100 lookup dianxin

    32766: from all lookup main

    32767: from all lookup default

 
ip rule show显示的内容，大体上可以分为三段：

   第一段：冒号之前的数字，表示该路由表被匹配的优先顺序，数字越小，越早被匹配。这个优先级别范围是0~4亿多。默认0、32766、32767三个优先级别已被占用。如果在添加规则时没有定义优先级别，那么默认的优先级别会从32766开始递减，可以通过prio ID参数在设置路由表时添加优先级。

   第二段：from关键字，这里显示的是匹配规则，当前表示的是从哪里来的数据包，除了from关键字外，还有to、tos、fwmark、dev等等。

   第三段：loacl/main/default 这些都是路由表名称，表示数据包要从那个路由表送出去。local表包含本机路由及广播信息，main表就是我们route -n看到的内容，default表，默认为空。

重启网络服务可以看到路由策略生效，当然，client的访问到达server之前是需要智能DNS解析的功能来选择不同的到达路径的。

添加rule  以180.95.233.130/32为源的IP走路由表1111

ip rule add from 180.95.233.130/32 table 111

Ip rule add from 180.95.233.130/32 table 111 pref 100

pref即路由表内序号，如果不加pref，则将在已有的规则最小序号前插入

ip rule add from 192.168.82.1 table tel2 pref 100

    [root@zebra ~]# ip rule sh

    0:      from all lookup local

    100:    from 192.168.82.1 lookup tel2

    32762:  from 192.168.82.1 lookup tel2

为路由表111添加默认路由180.95.233.129

ip route add 0/0(default) via 180.95.233.129 table 111

Linux 下不等价负载

实现linux下使用默认路由的weight来控制去每个出口的流量比例

1、全局路由表下生成两条负载默认路由

ip route add default scope global

nexthop via $P1 dev $IF1 weight 1

 nexthop via $P2 dev $IF2 weight 1

 
ip ro sh

default

nexthop via 192.168.81.2  dev eth2.801 weight 1

nexthop via 192.168.82.2  dev eth2.802 weight 1

这样生成了两条等价的负载路由

 
2、在指定路由表中生成两条默认路由

ip rout change default table 1881

nexthop via 10.222.22.1 dev p1p2.222

nexthop via 10.16.16.1 dev p1p2.111

[root@JXCN-ZLCS-NAT ~]# ip rout sh table 1881

default

nexthop via 10.222.22.1  dev p1p2.222 weight 1

nexthop via 10.16.16.1  dev p1p2.111 weight 1

删除默认路由

ip rout del default

根据网卡设备决定路由表

用于将不同接口进来的数据包走指定的路由表。

 ip rule add dev eth0 table tel

 ip rule add dev eth1 table tel2

 
将流量定向走指定路由表

/sbin/vconfig add eth3 198

/sbin/ifconfig eth3.198 10.101.98.2/30

/sbin/vconfig add eth0 298

/sbin/ifconfig eth0.298 172.22.98.1/30

 
ip rout add default via 172.22.98.2 table 2298  创建table 2298

ip rule add dev eth3.198 table 2298    流量入口

ip rule add dev eth0.298 table 2298  流量出口

ip rout add  223.103.5.0/24      via 10.101.98.1 table 2298   回程路由

ip rout add  223.104.5.0/24      via 10.101.98.1 table 2298

验证配置

    [root@zebra ~]# ip rule sh

    0:      from all lookup local

    32762:  from all iif eth1 lookup tel2

    32763:  from all iif eth0 lookup tel

    32764:  from 192.168.82.1 lookup tel2

    32765:  from 192.168.81.1 lookup tel

    32766:  from all lookup main

    32767:  from all lookup default

 
将接口从指定路由表中删除

 ip rule del dev eth1 table tel2

根据目标IP决定路由表

 将一些目标IP指定从哪些出口走

 ip rule add to 220.181.75.1 table tel2

 

验证

    [root@zebra ~]# ip rule sh

    0:      from all lookup local

    32763:  from all to 220.181.75.1 lookup tel2

    32764:  from 192.168.82.1 lookup tel2

    32765:  from 192.168.81.1 lookup tel

    32766:  from all lookup main

    32767:  from all lookup default

 
根据源IP决定路由表

基于源IP的路由，相当于PBR

 ip rule add from 192.168.82.1 table tel2

 

验证配置

[root@zebra ~]# ip rule sh

0:      from all lookup local

32762:  from 192.168.82.1 lookup tel2

 

删除策略

 ip rule del  from 192.168.82.1 table tel2

删除路由条目的几种方法

根据明细条目删除

 ip rule del from 192.168.10.10

根据优化级删除

 ip rule del prio 32765

 

根据路由名称来删除

 ip rule del table tel2

 

查看链路信息

 ip link show

查看IP配置信息

 ip addr show

查看arp 缓冲表

 ip neighbor show

[root@zebra ~]# ip neighbor show

103.246.132.77 dev eth0 lladdr 28:10:7b:54:f2:d1 REACHABLE

103.246.132.244 dev eth0 lladdr 00:0c:29:40:24:1d REACHABLE

192.168.82.2 dev eth2.802 lladdr 80:f6:2e:8d:39:b2 REACHABLE

192.168.81.2 dev eth2.801 lladdr 80:f6:2e:8d:39:b1 REACHABLE

删除邻居的MAC缓存

ip neighbor del 103.246.132.130 dev eth0

[root@zebra ~]# ip nei sh

103.246.132.130 dev eth0  FAILED

 
基于协议和端口进行流量分割

1、iptables -t mangle -A PREROUTING -i eth0.101 -p TCP –dport 80 -j MARK –set-mark 8080 

     eth0.101接口进来的流量目的端口为80的打标，8080

2、ip rout add default via 172.25.77.2 table 2577

   创建路由表

3、ip rule add  fwmark 8080 table 2577

      将MARK为8080的指定到路由表2577