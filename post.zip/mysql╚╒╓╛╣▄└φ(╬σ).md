---
title: "Mysql日志管理(五)"
date: 2019-09-29T18:05:18+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
Mysql日志管理
<!--more-->

日志类型

错误日志log-error

配置方法: [mysqld]

    log-error=/data/mysql/mysql.log •

查看配置方式： show variables like ‘%log%error%’; •

作用： – 记录mysql数据库的一般状态信息及报错信息，是我们对于数据库常规报错处理的常用日志。

一般查询日志

配置方法: [mysqld]

    general_log=on general_log_file=/data/mysql/server2.log

• 　查看配置方式： show 　variables　 like 　’%gen%’;

• 　作用： – 记录mysql所有执行成功的SQL语句信息，可以做审计用，但是 我们很少开启

二进制日志

二进制日志都记录了什么？

对数据库的所有修改的语句,对于事务语句,只记录提交的事务

以二进制的/以events大方式记录

事务事件的区别?

事务:begin—DML—commit

事件:begin 每个DML commit都算一个事件

一个事务至少由三个事件构成

对于事件来说,在一个二进制文件中,都有一个相对位置(position)

二进制日志记录方式

以events方式记录,每个events都有两个postion (at end_pos)

二进制日志设置

开启二进制日志

log-bin=/data/mysql/mysql-bin

set sql_log_bin=1/0 临时关闭或开启

二进制日志记录格式
binlog_format=row

statement

binlog管理
show variables like ‘%log_bin%’; 查询

ll /data/mysql/mysql-bin

show binary logs; 数据库二进制日志信息

show master status; 正在使用的日志

show binlog events in ‘mysql-bin.000004’ 查看事件信息日志

mysqlbinlog –start-position=6669 –stop=position=6855 mysql-bin.000004 >bak.sql

把这个阶段的事件导入bak．sql　以便恢复日志

reset master 删除之前的所有的二进制日志

set sql_log_bin=0 临时关闭二进制日志记录

flush logs; 分割日志　把mysql－bin.00000x分成多个

SET GLOBAL expire_logs_days = 7; 根据存在时间删除日志：

或者 PURGE BINARY LOGS BEFORE now() – INTERVAL 3 day;
根据文件名删除日志：PURGE BINARY LOGS TO ‘mysql-bin.000010’;

注意：有备份的情况下才可以设置，但是一定和全备周期有关

企业案例

物理删除恢复
    rm -rf /application/mysql/data/*　　　　误删整个数据库

    [root@db03 /data/mysql]# ll　　　　　　　在这个目录下是binlog日志

    total 12

    -rw-r–r– 1 root root 2989 Feb 9 13:20 bak.sql

    -rw-rw—- 1 mysql mysql 764 Feb 9 13:25 mysql-bin.000001

    -rw-rw—- 1 mysql mysql 764 Feb 9 13:25　mysql-bin.000002

    -rw-rw—- 1 mysql mysql 764 Feb 9 13:25　mysql-bin.000003

    -rw-rw—- 1 mysql mysql 29 Feb 9 13:25 mysql-bin.index

    [root@db03 /data/mysql]#　mysqlbinlog mysql-bin.000001 mysql-bin.000002 mysql-bin.000003 >bak.sql　　　把所有的日志记录导入一个sql文件

    [root@db03 /data/mysql]# ll

    total 12

    -rw-r–r– 1 root root 2989 Feb 9 13:20 bak.sql

初始化数据化

    /application/mysql/scripts/mysql_install_db –user=mysql –datadir=/application/mysql/data/ –basedir=/application/mysql

启动数据库

    /etc/init.d/mysqld start

把之前的日志清除

    reset master

导入日志

    mysql> source bak.sql

逻辑损坏
    mysql> create database oldboy;

    mysql> use oldboy;

    mysql> create table test(id int,name varchar(20));

    mysql> insert into test values(1,’zuma’),(2,’kaka’);

    mysql> show binary logs;

    +——————+———–+

    | Log_name | File_size |

    +——————+———–+

    | mysql-bin.000001 | 340 |

    +——————+———–+

    mysql> show binlog events in ‘mysql-bin.000001’;



    mysql> drop database oldboy;

    [root@db03 /data/mysql]# mysqlbinlog –stop-position=764 mysql-bin.000001>bak.sql

    source /data/mysql/bak.sql

    mysql> reset master

    mysql> source bak.sql

慢日志管理

慢查询日志

– 是将mysql服务器中影响数据库性能的相关SQL语句记录到日志文件

– 通过对这些特殊的SQL语句分析，改进以达到提高数据库性能的目的。

• 慢日志设置

– long_query_time ： 设定慢查询的阀值，超出次设定值的SQL即被记录到慢查 询日志，缺省值为10s

– slow_query_log ： 指定是否开启慢查询日志

– slow_query_log_file ： 指定慢日志文件存放位置，可以为空，系统会给一个缺 省的文件host_name-slow.log

– min_examined_row_limit：查询检查返回少于该参数指定行的SQL不被记录到慢查询 日志

– log_queries_not_using_indexes: 不使用索引的慢查询日志是否记录到索引

mysqldumpslow命令

mysqldumpslow命令 /path/mysqldumpslow -s c -t 10 /database/mysql/slow-log 这会输出记录次数最多的10条SQL语句，

其中：

-s 是表示按照何种方式排序，c、t、l、r分别是按照记录次数、时间、查询 时间、返回的记录数来排序，ac、at、al、ar，表示相应的倒叙；

-t 是top n的意思，即为返回前面多少条的数据；

-g, 后边可以写一个正则匹配模式，大小写不敏感的；

例子：

/path/mysqldumpslow -s r -t 10 /database/mysql/slow-log

得到返回记录集最多的10个查询。

/path/mysqldumpslow –s t -t 10 -g “left join”/database/mysql/slow-log


得到按照时间排序的前10条里面含有左连接的查询语句