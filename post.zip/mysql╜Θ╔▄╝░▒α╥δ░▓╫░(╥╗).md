---
title: "Mysql介绍及编译安装(一)"
date: 2019-09-29T18:03:31+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
mysql编译安装(在CentOS6.9使用mysql-5.6.36)
<!--more-->

下载好依赖包及cmake

    [root@db03 ~]# yum install -y ncurses-devel libaio-devel

    [root@db03 ~]# yum install cmake –y

创建用户

    [root@db03 ~]# useradd -s /sbin/nologin -M mysql

进行磁盘挂载并设置自动挂载

    [root@db03 ~]# mkfs.ext4 /dev/sdb

    [root@db03 ~]# mkdir /application

    [root@db03 ~]# mount /dev/sdb /application

    [root@db03 ~]#blkid 查看磁盘uuid

    [root@db03 ~]# blkid

    /dev/sda1: UUID=”0b3e70f6-b13b-4e9b-a7c9-760aec9208d9″ TYPE=”ext4″

    /dev/sda2: UUID=”8e1accac-bfec-46b5-af12-ffc03687ac5a” TYPE=”swap”

    /dev/sda3: UUID=”695e3d4e-509d-4b61-bec3-f83723e7a46a” TYPE=”ext4″

    /dev/sdb: UUID=”922fae13-dce5-4f6a-bc46-d80efeca1595″ TYPE=”ext4″

    [root@db03 ~]# vim /etc/fstab

    UUID= 922fae13-dce5-4f6a-bc46-d80efeca1595 /application ext4 defaults 0 0

解压安装

    [root@db03 ~]# cd /server/tools

    [root@db03 ~]# wget -q http://mirrors.sohu.com/mysql/MySQL-5.6/mysql-5.6.36.tar.gz

    [root@db03 /server/tools]# tar xf mysql-5.6.36.tar.gz

    [root@db03 /server/tools]# cd mysql-5.6.36

    [root@db03 mysql-5.6.36]# cmake . -DCMAKE_INSTALL_PREFIX=/application/mysql-5.6.36 \

    -DMYSQL_DATADIR=/application/mysql-5.6.36/data \

    -DMYSQL_UNIX_ADDR=/application/mysql-5.6.36/tmp/mysql.sock \

    -DDEFAULT_CHARSET=utf8 \

    -DDEFAULT_COLLATION=utf8_general_ci \

    -DWITH_EXTRA_CHARSETS=all \

    -DWITH_INNOBASE_STORAGE_ENGINE=1 \

    -DWITH_FEDERATED_STORAGE_ENGINE=1 \

    -DWITH_BLACKHOLE_STORAGE_ENGINE=1 \

    -DWITHOUT_EXAMPLE_STORAGE_ENGINE=1 \

    -DWITH_ZLIB=bundled \

    -DWITH_SSL=bundled \

    -DENABLED_LOCAL_INFILE=1 \

    -DWITH_EMBEDDED_SERVER=1 \

    -DENABLE_DOWNLOADS=1 \

    -DWITH_DEBUG=0

    [root@db03 mysql-5.6.36]# make && make install

    [root@db03 mysql-5.6.36]# ln -s /application/mysql-5.6.36/ /application/mysql

注:cmake作用
    1.定制软件的安装路径

    2.定制mysql的源程序和命令脚本

        bin/mysqld (二进制的) 关键守护程序源码

        bin/mysql

        bin/mysqld_safe

        scripts/mysql.server

        bin/mysqldump

        bin/mysqladmin

        supports-file/mysql_install_db

初始化数据库

    [root@HKX-01 mysql-5.6.36]# cp support-files/my*.cnf /etc/my.cnf

    [root@HKX-01 mysql-5.6.36]# /application/mysql/scripts/mysql_install_db –basedir=/application/mysql/ –datadir=/application/mysql/data –user=mysql

    [root@HKX-01 mysql-5.6.36]# chown -R mysql.mysql /application/mysql/

    [root@HKX-01 mysql-5.6.36]# cp support-files/mysql.server /etc/init.d/mysqld

    [root@HKX-01 mysql-5.6.36]# chmod 700 /etc/init.d/mysqld

    [root@HKX-01 mysql-5.6.36]# chkconfig mysqld on

    [root@HKX-01 mysql-5.6.36]# chkconfig –list mysqld

    mysqld     0:off    1:off    2:on    3:on    4:on    5:on    6:off

    [root@HKX-01 mysql-5.6.36]# /etc/init.d/mysqld start

    Starting MySQL.Logging to ‘/application/mysql-5.6.36/data/HKX-01.err’.

    180202 16:29:05 mysqld_safe Directory ‘/application/mysql-5.6.36/tmp’ for UNIX socket file don’t exists.

    ERROR! The server quit without updating PID file (/application/mysql-5.6.36/data/HKX-01.pid).
(mysql-5.7版本这时就可以启动服务)

mysql-5.6需要以下两步

    [root@HKX-01 mysql-5.6.36]# mkdir /application/mysql/tmp

    [root@HKX-01 mysql-5.6.36]# chown -R mysql.mysql /application/mysql/tmp

    [root@HKX-01 mysql-5.6.36]# echo ‘PATH=/application/mysql/bin/:$PATH’ >>/etc/profile

    [root@HKX-01 mysql-5.6.36]# tail -1 /etc/profile

    PATH=/application/mysql/bin/:$PATH

    [root@HKX-01 mysql-5.6.36]# source /etc/profile

启动mysql并设置登录用户及密码

    [root@HKX-01 mysql-5.6.36]# /etc/init.d/mysqld start

    Starting MySQL.Logging to ‘/application/mysql-5.6.36/data/HKX-01.err’.

    … SUCCESS!

    [root@HKX-01 mysql-5.6.36]# mysqladmin -u root password ‘oldboy123’

    [root@HKX-01 mysql-5.6.36]# mysql -uroot -poldboy123

mysql基础优化

    [root@db03 ~]# mysql -uroot -poldboy123

    Warning: Using a password on the command line interface can be insecure.

    Welcome to the MySQL monitor. Commands end with ; or \g.

    Your MySQL connection id is 1

    Server version: 5.6.36 Source distribution

    Copyright (c) 2000, 2017, Oracle and/or its affiliates. All rights reserved.

    Oracle is a registered trademark of Oracle Corporation and/or its

    affiliates. Other names may be trademarks of their respective

    owners.

    Type ‘help;’ or ‘\h’ for help. Type ‘\c’ to clear the current input statement.

    mysql> select user,host,password from mysql.user;

    +——+———–+——————————————-+

    | user | host | password |

    +——+———–+——————————————-+

    | root | localhost | *FE28814B4A8B3309DAC6ED7D3237ADED6DA1E515 |

    | root | db03 | |

    | root | 127.0.0.1 | |

    | root | ::1 | |

    | | localhost | |

    | | db03 | |

    +——+———–+——————————————-+

    6 rows in set (0.01 sec)

    mysql> drop user ”@’db03′;

    Query OK, 0 rows affected (0.00 sec)

    mysql> drop user ”@’localhost’;

    Query OK, 0 rows affected (0.00 sec)

    mysql> drop user ‘root’@’db03’;

    Query OK, 0 rows affected (0.00 sec)

    mysql> drop user ‘root’@’::1′;

    Query OK, 0 rows affected (0.00 sec)

    mysql> select user,host,password from mysql.user;

    +——+———–+——————————————-+

    | user | host | password |

    +——+———–+——————————————-+

    | root | localhost | *FE28814B4A8B3309DAC6ED7D3237ADED6DA1E515 |

    | root | 127.0.0.1 | |

    +——+———–+——————————————-+

    2 rows in set (0.00 sec)

    mysql> drop database test;

    Query OK, 0 rows affected (0.08 sec)

    mysql> show databases;

    +——————–+

    | Database |

    +——————–+

    | information_schema |

    | mysql |

    | performance_schema |

    +——————–+

    3 rows in set (0.01 sec)

常见问题:

故障:ERROR! The server quit without updating PID file

1.权限.chown -R mysql.mysql

2.killall mysqld

3.重新初始化数据.

4.运行1年了,出问题(非法（断电）关机或者非法关数据库，例如kill -9).

mysql体系结构
mysql服务器构成及访问方式
客户端通过TCP/IP来进行访问意识使用

mysql -uroot –poldboy123 -h10.0.0.52

客户端通过socket来访问

mysql -uroot –poldboy123 –S /application/mysql/tmp/mysql.socket

mysql多实例
客户请求到mysql时,通过mysql预分配的内存及mysqld统筹管理多个线程,分多个模块

MySQLD服务器程序构成

客户端通过应用程序到达连接层,其中包含了通信协议,线程,验证.接受客户的请求,判断其合法性,接受SQL并投递到下一层;

SQL层接受上一层的,判断语法,语义,权限,通过解析器解析SQL变为执行计划运行执行计划

RBO＋CBO优化器，选择以最小代价执行计划

执行器：负责执行选择的执行计划

查询缓存：将查询的数据信息缓存到内存区域当中, (把所有修改的操作记录 ),将结果送到下层

存储引擎判断上一层的执行结果,需要执行的地方

存储引擎
存储引擎是充当不同表类型的处理程序的服务器组件。

• 存储引擎用于：

– 存储数据

– 检索数据

– 通过索引查找数据

• 双层处理

– 上层包括SQL解析器和优化器

– 下层包含一组存储引擎

• SQL 层不依赖于存储引擎：

– 引擎不影响SQL处理

– 有一些例外