---
title: "KVM常用操作"
date: 2019-09-29T14:13:44+08:00
tags: 
- KVM
categories:
- KVM
archives:
- KVM
---
KVM常用的一些命令, 可以自己查看
<!--more-->
##### 1）通过配置文件启动虚拟机
virsh create /etc/libvirt/qemu/wintest01.xml
##### 2）配置开机自启动虚拟机
virsh autostart oeltest01
autostart目录是kvm虚拟机开机自启动目录，可以看到该目录中有KVM配置文件链接。
##### 3）导出KVM虚拟机配置文件
virsh dumpxml wintest01 > /etc/libvirt/qemu/wintest02.xml

KVM虚拟机配置文件可以通过这种方式进行备份。
##### 4）添加与删除KVM虚拟机
删除kvm虚拟机
virsh undefine wintest01

说明：该命令只是删除wintest01的配置文件，并不删除虚拟磁盘文件。

重新定义虚拟机配置文件

通过导出备份的配置文件恢复原KVM虚拟机的定义，并重新定义虚拟机。

 mv /etc/libvirt/qemu/wintest02.xml /etc/libvirt/qemu/wintest01.xml

virsh define /etc/libvirt/qemu/wintest01.xml

vim /etc/libvirt/qemu/wintest01.xml

###### 5）创建虚拟机
    [root@localhost ~]# virt-install –name=centos1 \ #生成一个虚拟机
    –ram 1024 –vcpus=1 \
    –disk path=/root/centos1.img,size=10 \
    –accelerate –cdrom /root/CentOS-6.5-x86_64-bin-DVD1.iso \
    –graphics vnc,port=5921 –network bridge=br0

##### 6）virsh的其他操作
    [root@localhost /]# virt-viewer centos1 #如果有图形界面的话，可以进入虚拟机的界面
    [root@localhost /]# virsh reboot centos1 #重启虚拟机
    [root@localhost /]# virsh suspend centos1 #暂停虚拟机
    [root@localhost /]# virsh resume centos1 #恢复虚拟机
    [root@localhost /]# virsh autostart centos1 #自动加载虚拟机

——————————————-virsh参数如下——————————————-

    autostart      #自动加载指定的一个虚拟机
    connect        #重新连接到hypervisor
    console        #连接到客户会话
    create         #从一个SML文件创建一个虚拟机
    start          #开始一个非活跃的虚拟机
    destroy        #删除一个虚拟机
    define         #从一个XML文件定义一个虚拟机
    domid          #把一个虚拟机名或UUID转换为ID
    domuuid        #把一个郁闷或ID转换为UUID
    dominfo        #查看虚拟机信息
    domstate       #查看虚拟机状态
    domblkstat     #获取虚拟机设备快状态
    domifstat      #获取虚拟机网络接口状态
    dumpxml        #XML中的虚拟机信息
    edit           #编辑某个虚拟机的XML文件
    list           #列出虚拟机
    migrate        #将虚拟机迁移到另一台主机
    quit           #退出非交互式终端
    reboot         #重新启动一个虚拟机
    resume         #重新恢复一个虚拟机
    save           #把一个虚拟机的状态保存到一个文件
    dump           #把一个虚拟机的内核dump到一个文件中以方便分析
    shutdown       #关闭一个虚拟机
    setmem         #改变内存的分配
    setmaxmem      #改变最大内存限制值
    suspend        #挂起一个虚拟机
    vcpuinfo       #虚拟机的cpu信息
    version        #显示virsh版本
###### 7）virt-clone，如果我们要建几个一样的虚拟机，这个命令，非常有用！
    virt-clone –connect=qemu:#/system -o centos1 -n centos3 -f /root/centos3.img #克隆centos1

libguestfs-tools是虚拟机一个管理包，很有用的工具
    yum -y install libguestfs-tools #安装工具包
##### 8）未登录的情况下，查看镜像目录
    virt-ls centos.img /home #查看centos.img镜像文件中/home目录

##### 9）查看虚拟机的分区情况
    [root@localhost ~]# virt-filesystems -d centos1
    /dev/sda1
    /dev/VolGroup/lv_root
    [root@localhost ~]# virt-list-partitions /root/centos.img
    /dev/sda1
    /dev/sda2
    [root@localhost ~]# virt-df centos.img
    Filesystem 1K-blocks Used Available Use%
    centos.img:/dev/sda1 495844 34510 435734 7%
    centos.img:/dev/VolGroup/lv_root 8780808 2842056 5492700 33%
##### 10）mount虚拟机
    [root@localhost ~]# guestmount -a /root/centos.img -m /dev/VolGroup/lv_root –rw /mnt/usb
    [root@localhost ~]# cd /mnt/usb/
    [root@localhost usb]# ls
    bin dev home lib64 media mnt opt root selinux sys usr
    boot etc lib lost+found misc net proc sbin srv tmp var