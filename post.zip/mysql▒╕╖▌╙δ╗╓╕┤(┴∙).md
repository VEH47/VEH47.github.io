---
title: "Mysql备份与恢复(六)"
date: 2019-09-29T18:05:39+08:00
tags: 
- Mysql
categories:
- Mysql
archives:
- Mysql
---
MySQL备份恢复介绍
<!--more-->

备份的目的：
为了恢复（故障、迁移、环境搭建）

数据库故障：物理、逻辑

备份的类型：

热备：可以在不太影响数据库正常运行情况下备份，主要针对支持事务的存储引擎

冷备：关闭业务进行数据库备份，所有的存储引擎均可

温备：锁表备份，主要针对不支持事务的存储引擎

备份方式：

逻辑备份（将数据库数据转换为SQL语句）

物理备份（将数据库的数据文件（数据页）进行备份）

增量备份（逻辑（binlog）、物理（工具需支持功能））

主从复制（逻辑备份）

快照备份（依赖于高端硬件存储设备或者LVM）

备份工具：

mysqlbinlog（逻辑备份）实现binlog备份的原生态命令

mysqldump（逻辑备份）mysql原生自带很好用的逻辑备份工具

使用SQL语句（逻辑备份）

xtrabackup（物理备份）precona公司开发的性能很高的物理备份工具

备份工具的使用

mysqldump

介绍：mysql自带的，不需要单独安装，企业最常用的工具, 原生态的版本不支持增量备份，必须配合binlog实现增量

全库备份(-A –all-databases)
-R –routines            备份存储过程和函数数据

–triggers         备份触发器数据

musqldump -A >/backup/full.sql

mysqldump -A -R –triggers >/backup/full.sql

单库备份
1、mysqldump oldboy >/backup/oldboy.sql (只能备份一个库)

2、mysqldump -B oldboy >/backup/oldboy_b.sql (可以备份多个库也就是多库备份)

 
注：

第一种方式，实现的是单库备份，但不带有create和use语句，恢复时需要事先创建好相应的库

第二种方式，实现的是单库备份，同时带有create和use语句，恢复时不需要实现创建对应库

多库备份

mysqldump -B oldboy oldgirl >/backup/two.sql

单表备份
mysqldump oldboy test >/backup/test.sql

库名
表名

-F, –flush-logs 刷新binlog日志(回顾binlog)

全备结束后，全备之前的binlog不再有用了。也就意味着，我们只要保留全备完成时刻之后的所有二进制日志，就认为数据库是安全的。所以-F选项的作用是，备份完成之后，刷新出新的二进制日志开始使用。我们将来只要保留从这个文件开始所有的二进制日志文件，就可以做数据库故障时的完整恢复。

每天晚上0点备份数据库

mysqldump -A -F >/backup/$(date +%F).sql

–master-data={1|2} 告诉你备份后时刻的binlog位置
1 非注释,要执行(主从复制) 2 注释

mysqldump -A –master-data=2 >/backup/$(date +%F-%T).sql

sed -n ’22p’ 2018-02-09-13:18:48.sql

 
注释：master-data 隐含条件，会自动对表进行加锁操作

非事务引擎

生产中需要进行锁表温备

-x

-l

事务引擎(开启快照备份) –single-transaction
压缩备份
mysqldump -B –master-data=2 oldboy|gzip>/backup/t1.sql.gz

解压:

zcat t.sql.gz>t1.sql

gzip -d t.sql.gz

gunzip t.sql.gz

innodb引擎的备份命令如下

mysqldump -A -R –triggers –master-data=2 –single-transaction |gzip>/backup/all.sql.gz

适合多引擎混合（例如：myisam与innodb混合）的备份命令如下

mysqldump -A -R –triggers –master-data=2 |gzip>/backup/alL_$(date +%F).sql.gz

常用的参数 -A -B –master-data –single-transaction -R –triggers

恢复数据

利用备份恢复

    set sql_log_bin=0

    source /backup/oldboy.sql

备份+binlog进行恢复

每天夜里11点进行生产数据全备

生产库：oldboy world mysql

    mysqldump -B oldboy world mysql –master-data=2 –single-transaction -R –triggers |gzip>/backup/alL_$(date +%F).sql.gz

26号12:00，开发人员，误删除oldboy下的test表所有数据

求恢复：

1、关闭业务

2、准备临时库

3、找到25号生产数据全备，恢复到临时库

4、找到从25号11点开始，到26号12点误删除操作之前的所有binlog，进行恢复

5、把误删除的数据从测试库，导出恢复到生产库

6、测试应用可用性和数据准确性

7、数据不完整，进行手工补偿

8、开启业务

结果：数据成功恢复，30分钟业务恢复正常

mysqldump优缺点：

优点：

1、自带的工具，不需要额外安装配置，使用方便

2、备份参数丰富

3、备份文件是明文

4、备份出的数据占用空间小，便于压缩（压缩速度快、压缩比高）

缺点：

1、备份和恢复都依赖于数据库实例

2、备份速度相对比较慢

30GB以下，可以使用mysqldump

30GB以上，很多企业不会选择mysqldump

TB级别，根据公司成本评估使用什么备份工具

PB级别以上的系统，还是会选择使用mysqldump

物理备份工具

安装物理备份工具

    wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-6.repo

    yum -y install perl perl-devel libaio libaio-devel perl-Time-HiRes perl-DBD-MySQL

    wget https://www.percona.com/downloads/XtraBackup/Percona-XtraBackup-2.4.4/binary/redhat/6/x86_64/percona-xtrabackup-24-2.4.4-1.el6.x86_64.rpm

    yum -y install percona-xtrabackup-24-2.4.4-1.el6.x86_64.rpm

物理的备份工具 (不明白)

直接拷贝数据文件的方式

热备份工具（只针对于支持事务的存储引擎）

热备的实现原理

crash safe recovery

commit —->redo 持久化(并且已经打上commit标记了) undo也持久化了

uncommit —->redo持久化了（没有打上commit），undo也持久化了

全备备份

    [root@db03 /backup]# innobackupex –user=root –password=oldboy123 /backup

    …………..

    xtrabackup: Transaction log of lsn (3065630) to (3065630) was copied.

    180226 16:48:26 completed OK!

备份完成之后，会自动创建一个基于当前时间戳的目录，存放全备备份集

    [root@db03 /backup]# ll

    total 19020

    drwxr-x— 7 root root 4096 Feb 26 16:48 2018-02-26_16-48-01

    [root@db03 /backup]# cd 2018-02-26_16-48-01/

    [root@db03 /backup/2018-02-26_16-48-01]# ll

    total 77864

    -rw-r—– 1 root root 419 Feb 26 16:48 backup-my.cnf

    -rw-r—– 1 root root 79691776 Feb 26 16:48 ibdata1

    drwxr-x— 2 root root 4096 Feb 26 16:48 mysql

    drwxr-x— 2 root root 4096 Feb 26 16:48 oldboy

    drwxr-x— 2 root root 4096 Feb 26 16:48 performance_schema

    drwxr-x— 2 root root 4096 Feb 26 16:48 RUNOOB

    drwxr-x— 2 root root 4096 Feb 26 16:48 world

    -rw-r—– 1 root root 21 Feb 26 16:48 xtrabackup_binlog_info

    -rw-r—– 1 root root 113 Feb 26 16:48 xtrabackup_checkpoints

    -rw-r—– 1 root root 463 Feb 26 16:48 xtrabackup_info

    -rw-r—– 1 root root 2560 Feb 26 16:48 xtrabackup_logfile

（在备份数据同时，redo的日志信息备份）

模拟误删库

关闭数据库(因为/mysql/data目录下文件全部被删,所以无法正常关闭)

pkill mysqld

恢复数据前准备

将已提交的事务redo合并到磁盘备份中（模拟的是crash safe recovery），并且将未提交的数据进行回滚

innobackupex –apply-log /backup/2018-02-09_18-28-26

恢复备份

cp -a /backup/2018-02-09_18-28-26/* /application/mysql/data

或者

innobackupex –copy-back /backup/2018-02-09_18-28-26

改权限并启动数据库

[root@db03 /application/mysql/data]# chown -R mysql.mysql /application/

[root@db03 /application/mysql/data]# /etc/init.d/mysqld start

Starting MySQL…. SUCCESS!

其他备份参数

–no-timestamp 取消备份时间戳

–parallel=4     和cpu核数线程有关

innobackupex –no-timestamp /backup/full/ 自己命名

增量备份–incremental= –incremental-basedir=

增量备份模拟案例

周日全备
innobackupex –no-timestamp /backup/full/

模拟数据

    use oldboy

    delete from test;

    insert into test values(1,’full01′);

    insert into test values(2,’full02′);

    insert into test values(3,’full03′);

    insert into test values(4,’full04′);

    insert into test values(5,’full05′);

检查:

select * from test;

进行周一增量

innobackupex –no-timestamp –incremental /backup/inc1/ –incremental-basedir=/backup/full/

周二数据被修改

mysql -e “use oldboy;insert into test values(6,’new_inc_one_1′);commit;”

mysql -e “use oldboy;insert into test values(7,’new_inc_one_2′);commit;”

mysql -e “select * from oldboy.test;”

周二增量备份

innobackupex –no-timestamp –incremental /backup/inc2/ –incremental-basedir=/backup/inc1

故障模拟：

周3上午10点，oldboy下的test表，数据被误修改

思路：

1、关闭业务

2、查找备份，周日全备
周一增量

周二增量

3、找临时库

4、合并所有增量到全备当中

（1）全备的apply-log

innobackupex –apply-log –use-memory=32M –redo-only /backup/full

（2）周一增量合并到全备

innobackupex –apply-log –use-memory=32M –redo-only –incremental-dir=/backup/inc1 /backup/full/

（3）周2增量合并到全备

innobackupex –apply-log –use-memory=32M –incremental-dir=/backup/inc2 /backup/full/

（4）合并完成之后进行整体apply-log

innobackupex –apply-log /backup/full/

5、恢复数据到临时库

pkill mysqld 关闭数据库

innobackupex –copy-back /backup/full

目前的状态是

周2 备份时间的数据状态

6、使用binlog补全，周2 00:10之后到误update 之间的数据操作

7、测试库恢复完成后，导出问题表，倒回到生产库，测试应用，测试没问题开启业务。

xtrabackup 导出表
“导出”表

导出表是在备份的prepare阶段进行的，因此，一旦完全备份完成，就可以在prepare过程中通过–export选项将某表导出了：

####innobackupex –apply-log –export /path/to/backup

此命令会为每个innodb表的表空间创建一个以.exp结尾的文件，这些以.exp结尾的文件则可以用于导入至其它服务器。

“导入”表

要在mysql服务器上导入来自于其它服务器的某innodb表，需要先在当前服务器上创建一个跟原表表结构一致的表，而后才能实现将表导入：

mysql> CREATE TABLE mytable (…) ENGINE=InnoDB;

然后将此表的表空间删除：

mysql> ALTER TABLE mydatabase.mytable DISCARD TABLESPACE;

接下来，将来自于”导出”表的服务器的mytable表的mytable.ibd和mytable.exp文件复制到当前服务器的数据目录，然后使用如下命令将其”导入”：

mysql> ALTER TABLE mydatabase.mytable IMPORT TABLESPACE;